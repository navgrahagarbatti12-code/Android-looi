# LOOI AI – Native Android Companion Project

A complete native Kotlin + XML Android Studio project for LOOI AI featuring:
- Expressive full-screen robot face (`RobotFaceCanvasView`) with two glowing eyes, natural random blinking, synchronized pupil tracking, smooth emotion transitions, and lip-sync.
- Real-time front camera preview + ML Kit Face Tracking & Object Detection (`CompositeVisionAnalyzer` + CameraX).
- Two-way voice conversation (`SpeechRecognizer` + `TextToSpeech`) with configurable **Groq API** (`llama-3.3-70b-versatile`) or optional companion backend proxy.
- Persistent Room SQLite conversation memory (`AppDatabase` + `MemoryRepository`).
- Full Settings screen (`SettingsActivity`) for AI API configuration, voice selection, speech speed, eye animation speed, camera/object detection toggles, sound, and privacy controls.

## 1. Android Studio Setup
1. Extract the ZIP and open the `looi-ai-android/` folder in **Android Studio** (Jellyfish / Koala / Ladybug or newer).
2. Let Gradle sync using the included `gradle/libs.versions.toml` version catalog (AGP `8.5.2`, Gradle `8.7`, Kotlin `1.9.24`, JDK 17).
3. Connect a physical Android device (API 26+) with USB Debugging enabled (recommended for front camera & microphone) or use an emulator with front camera + mic enabled.

## 2. API Configuration (No Hardcoded Keys)
1. Get a free Groq API key from [console.groq.com](https://console.groq.com).
2. Launch the app on your device and tap the **Settings** icon (top right).
3. Paste your Groq API key (`gsk_...`) into **Groq API Key** and tap **Save Settings**.
   - Your key is stored locally on-device in private `SharedPreferences` and is never hardcoded in source code.
   - Optionally, you can configure a custom **Backend Proxy URL** (e.g. `http://10.0.2.2:3000` for Android Emulator) and switch **AI Provider Mode** to `Companion Backend Proxy`.
   - Production network security enforces HTTPS by default; cleartext HTTP is restricted strictly to local loopback/emulator hosts (`10.0.2.2`, `localhost`, `127.0.0.1`) via `res/xml/network_security_config.xml`.

## 3. Build & Install APK
From the `looi-ai-android/` directory (in Android Studio Terminal or local shell with Android SDK installed):
```bash
# Build Debug APK (macOS / Linux)
./gradlew assembleDebug

# Build Debug APK (Windows)
gradlew.bat assembleDebug

# Install directly to connected device
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
For a release APK, configure a signing key in Android Studio via **Build > Generate Signed Bundle / APK**.

## 4. Security notes
- The Groq key is stored only in Android Keystore-backed `EncryptedSharedPreferences`. If the device cannot provide secure storage, the key is kept **in memory for the current session only** and is never written to plain-text prefs.
- The key is never logged and never compiled into the APK. **Do not commit keys**; the CI workflow fails if a `gsk_...` string is found in the repo. The app needs no GitHub secrets to build; users enter their key inside the app (🔒 button or Settings).
- Network: Groq is called over HTTPS. Backend URLs must be `https://` (plain `http://` only for `10.0.2.2`, `localhost`, `127.0.0.1`).
- The "Gemini Companion Backend" is a separate server you run yourself (`POST <url>/api/looi/chat` -> `{"reply": "..."}`); the app has no Gemini key.

## 5. GitHub Actions
`.github/workflows/build-apk.yml` runs on push to `main`/`master`, on pull requests, and manually (Actions > Build Android APK > Run workflow). It runs unit tests, builds the debug APK and uploads it as the `LOOI-AI-debug-apk` artifact; on failure it uploads `build-reports`.

## 6. Database
Room schema version 2 (migration 1->2 adds a timestamp index). Schemas are exported to `app/schemas/` - commit them. Long-press a message in Chat Log to delete it.

## 7. Phase 1 additions (v1.1.0): Brain, Personality, Memory, Eyes

**Personalities** (Settings > Personality & Memory): Friendly, Funny, Intelligent, Curious, Emotional, Helpful. Each changes the AI's tone, sampling temperature, voice pitch/speed, idle expression and how the face reacts to what you say.

**Brain** (`ai/brain/`): every turn sends Groq a real multi-turn conversation: system prompt (personality, language, date/time, vision), relevant saved memories, related lines from older chats, the last 12 turns, and your message. Replies end with a hidden `[emotion:...]` tag that drives the face; tags are stripped before display and speech. Replies match your language (Hindi in Devanagari, Hinglish, English). Models: pick from the list, type a custom ID, or tap **Fetch available models from Groq** to load the models your key can use.

**Memory** (Room DB v3, migration 2 to 3 keeps your history):
- Say *"remember that my sister is Riya"* / *"yaad rakho ki ..."* to save. Say *"forget about ..."*, *"what do you remember about me?"*, *"search my old conversations for cricket"*.
- The AI may *suggest* a memory; a dialog asks Save / No thanks. Nothing is saved without approval.
- Passwords, OTPs, card/bank/ID numbers are refused everywhere and never written to chat history.
- Settings > **Open Memory Vault**: view, search, add and delete memories and old chats; Delete all.
- Settings switches: long-term memory on/off, AI suggestions on/off, save history on/off.

**Eyes**: random single and double blinks, idle glances when no face is visible, look up-left while thinking, look at you while listening, small gaze drift while speaking, wake-up "pop", animation fully paused while the app is in the background.

**Tests**: `./gradlew testDebugUnitTest` (38 JVM tests: language detection, memory commands, privacy filter, reply parsing, memory ranking, prompt building, personalities, validators).

See `docs/FEATURE_REPORT.md` for the per-feature status of the full 10-section roadmap.
