# LOOI AI – Native Android Companion Project

A complete native Kotlin + XML Android Studio project for LOOI AI featuring:
- Expressive full-screen robot face (`RobotFaceCanvasView`) with two glowing eyes, natural random blinking, synchronized pupil tracking, smooth emotion transitions, and lip-sync.
- Real-time front camera preview + ML Kit Face Tracking & Object Detection (`CompositeVisionAnalyzer` + CameraX).
- Two-way voice conversation (`SpeechRecognizer` + `TextToSpeech`) with configurable **Groq API** (`llama-3.3-70b-versatile`) or optional companion backend proxy.
- Persistent Room SQLite conversation memory (`AppDatabase` + `MemoryRepository`).
- Full Settings screen (`SettingsActivity`) for AI API configuration, voice selection, speech speed, eye animation speed, camera/object detection toggles, sound, and privacy controls.

## 1. Android Studio Setup
1. Extract the ZIP and open the `looi-ai-android/` folder in **Android Studio** (Jellyfish / Koala / Ladybug or newer).
2. Let Gradle sync using the included `gradle/libs.versions.toml` version catalog (AGP `8.5.2`, Gradle `8.7`, Kotlin `1.9.24`, JDK 17).
3. Connect a physical Android device (API 26+) with USB Debugging enabled (recommended for front camera & microphone) or use an emulator with front camera + mic enabled.

## 2. API Configuration (No Hardcoded Keys)
1. Get a free Groq API key from [console.groq.com](https://console.groq.com).
2. Launch the app on your device and tap the **Settings** icon (top right).
3. Paste your Groq API key (`gsk_...`) into **Groq API Key** and tap **Save Settings**.
   - Your key is stored locally on-device in private `SharedPreferences` and is never hardcoded in source code.
   - Optionally, you can configure a custom **Backend Proxy URL** (e.g. `http://10.0.2.2:3000` for Android Emulator) and switch **AI Provider Mode** to `Companion Backend Proxy`.
   - Production network security enforces HTTPS by default; cleartext HTTP is restricted strictly to local loopback/emulator hosts (`10.0.2.2`, `localhost`, `127.0.0.1`) via `res/xml/network_security_config.xml`.

## 3. Build & Install APK
From the `looi-ai-android/` directory (in Android Studio Terminal or local shell with Android SDK installed):
```bash
# Build Debug APK (macOS / Linux)
./gradlew assembleDebug

# Build Debug APK (Windows)
gradlew.bat assembleDebug

# Install directly to connected device
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
For a release APK, configure a signing key in Android Studio via **Build > Generate Signed Bundle / APK**.
