# Proguard rules for LOOI AI
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class com.looi.ai.memory.database.** { *; }
-keep class com.looi.ai.ai.gemini.** { *; }
-keep class com.looi.ai.ai.groq.** { *; }
