package com.looi.ai.ai.brain

import com.looi.ai.ai.AiRouter
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.memory.MemoryRepository
import com.looi.ai.memory.MemorySaveResult
import com.looi.ai.personality.RobotPersonality
import com.looi.ai.settings.SettingsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * What the UI shows and speaks.
 * [memoryProposal] is a fact the AI suggests saving; the UI must ask the user before calling
 * [BrainController.saveApprovedMemory].
 */
data class BrainReply(
    val text: String,
    val emotion: RobotEmotion?,
    val memoryProposal: String?,
    val handledLocally: Boolean
)

/**
 * The robot's brain: understands memory commands locally, otherwise builds a context-rich prompt
 * (personality, language, relevant memories, recalled old chats, recent history, vision) and sends it
 * through [AiRouter]. Also persists the conversation when history saving is enabled.
 */
class BrainController(
    private val settings: SettingsManager,
    private val router: AiRouter,
    private val memory: MemoryRepository,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {

    suspend fun respond(
        userText: String,
        userEmotion: String,
        visibleObjects: List<String>
    ): Result<BrainReply> {
        val lang = LanguageDetector.detect(userText)

        val local = handleMemoryCommand(MemoryIntentParser.parse(userText), lang)
        if (local != null) {
            record(userText, userEmotion, local.text)
            return Result.success(local)
        }

        val personality = RobotPersonality.fromId(settings.personalityId)
        val now = clock()
        val memoryOn = settings.longTermMemoryEnabled
        val historyOn = settings.saveHistoryEnabled

        // Read context BEFORE recording this turn so the question is not sent twice.
        val window = memory.recentWindow()
        val ranked = if (memoryOn) MemoryRanker.select(memory.getRankableMemories(), userText, now)
        else RankedMemories(emptyList(), emptyList())
        val recalled = if (historyOn) memory.recallSnippets(userText, window.oldestTimestamp) else emptyList()

        val ctx = BrainContext(
            userText = userText,
            personality = personality,
            language = lang,
            preferredLanguageCode = settings.languageCode,
            memories = ranked,
            recalledSnippets = recalled,
            history = window.messages,
            userEmotion = userEmotion,
            visibleObjects = visibleObjects,
            nowText = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date(now)),
            allowMemoryProposals = memoryOn && settings.memoryProposalsEnabled
        )

        val result = router.converse(
            messages = PromptBuilder.build(ctx),
            userMessage = userText,
            detectedEmotion = userEmotion,
            detectedObjects = visibleObjects,
            temperature = personality.temperature
        )

        return result.map { raw ->
            val parsed = ReplyParser.parse(raw)
            val spoken = parsed.text.ifBlank { raw.trim() }
            record(userText, userEmotion, spoken)
            BrainReply(
                text = spoken,
                emotion = parsed.emotion,
                memoryProposal = if (ctx.allowMemoryProposals) parsed.memoryProposal else null,
                handledLocally = false
            )
        }
    }

    /** Called by the UI only after the user tapped "Save" on a suggestion. */
    suspend fun saveApprovedMemory(text: String): MemorySaveResult {
        if (!settings.longTermMemoryEnabled) return MemorySaveResult.INVALID
        return memory.addMemory(text, MemoryRepository.SOURCE_APPROVED)
    }

    // ------------------------------------------------------------------ local commands

    private suspend fun handleMemoryCommand(intent: MemoryIntent, lang: UserLanguage): BrainReply? = when (intent) {
        MemoryIntent.None -> null

        is MemoryIntent.Remember -> {
            if (!settings.longTermMemoryEnabled) {
                local(lang, RobotEmotion.SAD,
                    "Long-term memory is turned off in Settings, so I can't save that.",
                    "Long-term memory Settings me band hai, isliye save nahi kar sakta.",
                    "सेटिंग्स में लंबी याददाश्त बंद है, इसलिए मैं इसे सेव नहीं कर सकता।")
            } else when (memory.addMemory(intent.text, MemoryRepository.SOURCE_COMMAND)) {
                MemorySaveResult.SAVED -> local(lang, RobotEmotion.HAPPY,
                    "Got it, I'll remember that: ${intent.text}.",
                    "Theek hai, yaad rakh liya: ${intent.text}.",
                    "ठीक है, मैंने याद कर लिया: ${intent.text}।")
                MemorySaveResult.DUPLICATE -> local(lang, RobotEmotion.HAPPY,
                    "I already knew that one.", "Ye to mujhe pehle se pata tha.", "यह तो मुझे पहले से पता था।")
                MemorySaveResult.SENSITIVE -> local(lang, RobotEmotion.SURPRISED,
                    "I won't store passwords, OTPs, or card and ID numbers. That stays private.",
                    "Main password, OTP ya card aur ID number save nahi karta. Wo private rehna chahiye.",
                    "मैं पासवर्ड, ओटीपी या कार्ड और आईडी नंबर सेव नहीं करता। वह निजी रहना चाहिए।")
                MemorySaveResult.INVALID -> local(lang, RobotEmotion.CURIOUS,
                    "That's too short or too long for me to remember. Try a single short sentence.",
                    "Ye bahut chhota ya bahut lamba hai. Ek chhota sa vakya bolkar dekhein.",
                    "यह बहुत छोटा या बहुत लंबा है। एक छोटा वाक्य बोलकर देखें।")
            }
        }

        is MemoryIntent.Forget -> {
            val everything = intent.text.lowercase() in setOf("everything", "all", "all of it", "sab kuch", "sab", "सब कुछ")
            if (everything) {
                local(lang, RobotEmotion.CURIOUS,
                    "To delete everything, open Settings, then Memory Vault, and tap Delete all. I want you to be sure.",
                    "Sab kuch hatane ke liye Settings me Memory Vault kholkar Delete all dabayein. Main chahta hoon aap pakka karein.",
                    "सब कुछ हटाने के लिए सेटिंग्स में मेमोरी वॉल्ट खोलकर Delete all दबाएँ।")
            } else {
                val n = memory.forgetMatching(intent.text)
                if (n > 0) local(lang, RobotEmotion.HAPPY,
                    "Done. I forgot $n thing${if (n == 1) "" else "s"} about ${intent.text}.",
                    "Ho gaya. ${intent.text} ke baare me $n cheez${if (n == 1) "" else "ein"} bhool gaya.",
                    "हो गया। ${intent.text} के बारे में $n बात भूल गया।")
                else local(lang, RobotEmotion.CURIOUS,
                    "I couldn't find anything about ${intent.text} in my memory.",
                    "${intent.text} ke baare me meri memory me kuch nahi mila.",
                    "${intent.text} के बारे में मेरी याददाश्त में कुछ नहीं मिला।")
            }
        }

        MemoryIntent.ListMemories -> {
            val all = memory.getAllMemories()
            if (all.isEmpty()) local(lang, RobotEmotion.CURIOUS,
                "I don't have any saved memories yet. Say remember, and then tell me something.",
                "Abhi meri memory me kuch save nahi hai. Bolo yaad rakho, phir kuch batao.",
                "अभी मेरी याददाश्त में कुछ सेव नहीं है। कहिए याद रखो, फिर कुछ बताइए।")
            else {
                val items = all.take(6).joinToString("; ") { it.content }
                val more = all.size - 6
                local(lang, RobotEmotion.HAPPY,
                    "Here's what I remember: $items." + if (more > 0) " And $more more in the Memory Vault." else "",
                    "Mujhe ye yaad hai: $items." + if (more > 0) " Aur $more Memory Vault me hain." else "",
                    "मुझे यह याद है: $items।" + if (more > 0) " और $more मेमोरी वॉल्ट में हैं।" else "")
            }
        }

        is MemoryIntent.SearchConversations -> {
            val hits = memory.searchConversations(intent.query, limit = 5)
            if (hits.isEmpty()) local(lang, RobotEmotion.CURIOUS,
                "I couldn't find any earlier conversation about ${intent.query}.",
                "${intent.query} ke baare me pichli baat-cheet me kuch nahi mila.",
                "${intent.query} के बारे में पिछली बातचीत में कुछ नहीं मिला।")
            else {
                val top = hits.first()
                val date = SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(top.timestamp))
                val who = if (top.sender == "LOOI") "I said" else "You said"
                val snippet = top.messageText.take(110)
                local(lang, RobotEmotion.HAPPY,
                    "I found ${hits.size} earlier message${if (hits.size == 1) "" else "s"} about ${intent.query}. Latest, on $date, $who: $snippet",
                    "${intent.query} ke baare me ${hits.size} purane message mile. Sabse naya, $date ko, ${if (top.sender == "LOOI") "maine kaha" else "aapne kaha"}: $snippet",
                    "${intent.query} के बारे में ${hits.size} पुराने संदेश मिले। सबसे नया, $date को: $snippet")
            }
        }
    }

    private fun local(lang: UserLanguage, emotion: RobotEmotion, en: String, hinglish: String, hindi: String) =
        BrainReply(
            text = when (lang) {
                UserLanguage.ENGLISH -> en
                UserLanguage.HINGLISH -> hinglish
                UserLanguage.HINDI -> hindi
            },
            emotion = emotion,
            memoryProposal = null,
            handledLocally = true
        )

    /** Saves both sides of the turn. Messages that look like secrets are never written to history. */
    private suspend fun record(userText: String, userEmotion: String, reply: String) {
        if (!settings.saveHistoryEnabled) return
        if (!SensitiveDataFilter.isSensitive(userText)) {
            memory.recordUserMessage(userText, userEmotion)
            memory.recordLooiResponse(reply)
        }
    }
}
