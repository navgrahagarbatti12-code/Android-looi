package com.looi.ai.ai

import com.looi.ai.ai.brain.ChatMessage
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.settings.SettingsManager

/**
 * Single place that decides whether a chat turn goes to Groq directly or to the backend proxy,
 * so MainActivity and ConversationActivity behave identically.
 */
class AiRouter(
    private val settings: SettingsManager,
    private val groq: GroqManager,
    private val backend: GeminiLiveClient
) {
    suspend fun chat(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> {
        val useGroq = when (settings.aiProvider) {
            SettingsManager.PROVIDER_GROQ -> true
            SettingsManager.PROVIDER_BACKEND -> false
            else -> settings.groqApiKey.isNotBlank()
        }

        // AUTO mode with no key and the untouched emulator-only default URL can never work
        // on a real phone, so tell the user exactly what to do instead of a cryptic network error.
        if (!useGroq &&
            settings.aiProvider == SettingsManager.PROVIDER_AUTO &&
            settings.backendUrl == SettingsManager.DEFAULT_BACKEND_URL
        ) {
            return Result.failure(
                IllegalStateException("Groq API key set nahi hai. Settings kholkar apni Groq API Key (gsk_...) daalein.")
            )
        }

        return if (useGroq) {
            groq.chatCompletion(userMessage, detectedEmotion, detectedObjects, historyContext)
        } else {
            backend.sendConversationTurn(userMessage, detectedEmotion, detectedObjects, historyContext)
        }
    }

    /**
     * Multi-turn chat. Groq receives the full message list (system prompt, history, user turn).
     * The optional backend receives the plain fields it has always expected, with the history flattened.
     */
    suspend fun converse(
        messages: List<ChatMessage>,
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        temperature: Float
    ): Result<String> {
        val useGroq = when (settings.aiProvider) {
            SettingsManager.PROVIDER_GROQ -> true
            SettingsManager.PROVIDER_BACKEND -> false
            else -> settings.groqApiKey.isNotBlank()
        }
        if (!useGroq &&
            settings.aiProvider == SettingsManager.PROVIDER_AUTO &&
            settings.backendUrl == SettingsManager.DEFAULT_BACKEND_URL
        ) {
            return Result.failure(
                IllegalStateException("Groq API key set nahi hai. Settings kholkar apni Groq API Key (gsk_...) daalein.")
            )
        }
        return if (useGroq) {
            groq.complete(messages, temperature, maxTokens = 260)
        } else {
            val transcript = messages
                .filter { it.role != ChatMessage.SYSTEM }
                .dropLast(1)
                .joinToString("\n") { (if (it.role == ChatMessage.USER) "USER" else "LOOI") + ": " + it.content }
                .ifBlank { "No prior history." }
            backend.sendConversationTurn(userMessage, detectedEmotion, detectedObjects, transcript)
        }
    }
}
