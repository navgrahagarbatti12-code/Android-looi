package com.looi.ai.ai.brain

import com.looi.ai.personality.RobotPersonality

/** Everything the model needs to know for one turn. */
data class BrainContext(
    val userText: String,
    val personality: RobotPersonality,
    val language: UserLanguage,
    /** Settings language code such as "hi-IN"; used as a tie-breaker for very short messages. */
    val preferredLanguageCode: String,
    val memories: RankedMemories,
    /** Older conversation lines (outside the recent window) that match the user's topic. */
    val recalledSnippets: List<String>,
    val history: List<ChatMessage>,
    val userEmotion: String,
    val visibleObjects: List<String>,
    /** Human readable local date and time, supplied by the caller so this class stays pure. */
    val nowText: String,
    val allowMemoryProposals: Boolean
)

object PromptBuilder {
    private const val MAX_HISTORY_TURNS = 12
    private const val MAX_HISTORY_CHARS = 3200

    fun build(ctx: BrainContext): List<ChatMessage> {
        val out = ArrayList<ChatMessage>()
        out.add(ChatMessage(ChatMessage.SYSTEM, systemPrompt(ctx)))
        out.addAll(trimHistory(ctx.history))
        out.add(ChatMessage(ChatMessage.USER, ctx.userText))
        return out
    }

    fun systemPrompt(ctx: BrainContext): String = buildString {
        appendLine("You are LOOI AI, a small expressive robot companion living in the user's phone.")
        appendLine(ctx.personality.styleGuide)
        appendLine(LanguageDetector.replyInstruction(ctx.language))
        if (ctx.language == UserLanguage.ENGLISH && ctx.preferredLanguageCode.startsWith("hi")) {
            appendLine("If the user's message is very short or ambiguous, prefer casual Hinglish.")
        }
        appendLine("Your replies are spoken aloud: use 1 to 3 short sentences, plain text only, no markdown, no emoji, no lists.")
        appendLine("Answer questions accurately. If you do not know something, say so instead of guessing.")
        appendLine("Current local date and time: ${ctx.nowText}.")
        appendLine("The user currently looks ${ctx.userEmotion.lowercase()}.")
        if (ctx.visibleObjects.isNotEmpty()) {
            appendLine("Objects your camera sees right now: ${ctx.visibleObjects.joinToString(", ")}. Mention them only if relevant.")
        }

        if (ctx.memories.instructions.isNotEmpty()) {
            appendLine()
            appendLine("Standing instructions the user gave you (follow them):")
            ctx.memories.instructions.forEach { appendLine("- $it") }
        }
        if (ctx.memories.facts.isNotEmpty()) {
            appendLine()
            appendLine("Things the user asked you to remember (use naturally, do not recite):")
            ctx.memories.facts.forEach { appendLine("- $it") }
        }
        if (ctx.recalledSnippets.isNotEmpty()) {
            appendLine()
            appendLine("Related lines from earlier conversations:")
            ctx.recalledSnippets.forEach { appendLine("- $it") }
        }

        appendLine()
        appendLine("End every reply with exactly one tag showing your facial expression: [emotion:happy], [emotion:sad], [emotion:angry], [emotion:surprised] or [emotion:curious].")
        if (ctx.allowMemoryProposals) {
            appendLine("Only when the user states a lasting personal fact or preference worth remembering, also add [remember: short third-person fact]. The user will be asked to approve it. Never propose passwords, OTPs, card, bank or ID numbers, or health details.")
        }
    }.trim()

    /** Keeps the newest turns that fit both the turn and the character budget. */
    fun trimHistory(history: List<ChatMessage>): List<ChatMessage> {
        val kept = ArrayList<ChatMessage>()
        var chars = 0
        for (m in history.asReversed()) {
            if (kept.size >= MAX_HISTORY_TURNS) break
            if (chars + m.content.length > MAX_HISTORY_CHARS && kept.isNotEmpty()) break
            kept.add(m)
            chars += m.content.length
        }
        return kept.asReversed()
    }
}
