package com.looi.ai.memory.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY updatedAt DESC, id DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY updatedAt DESC, id DESC")
    suspend fun getAll(): List<MemoryEntity>

    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Update
    suspend fun update(memory: MemoryEntity)

    @Query("SELECT * FROM memories WHERE LOWER(content) = LOWER(:content) LIMIT 1")
    suspend fun findExact(content: String): MemoryEntity?

    @Query("SELECT * FROM memories WHERE content LIKE '%' || :escaped || '%' ESCAPE '\\' ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun search(escaped: String, limit: Int): List<MemoryEntity>

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteById(id: Long): Int

    @Query("DELETE FROM memories WHERE content LIKE '%' || :escaped || '%' ESCAPE '\\'")
    suspend fun deleteMatching(escaped: String): Int

    @Query("DELETE FROM memories WHERE id IN (SELECT id FROM memories ORDER BY updatedAt ASC, id ASC LIMIT :count)")
    suspend fun deleteOldest(count: Int): Int

    @Query("DELETE FROM memories")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM memories")
    suspend fun count(): Int
}
