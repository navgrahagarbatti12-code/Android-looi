package com.looi.ai.settings

/** Pure (Android-free) validators so they can be unit-tested on the JVM. */
object InputValidators {
    private val MODEL_ID_REGEX = Regex("^[A-Za-z0-9._:/-]{2,80}$")
    private val LOCAL_HTTP_HOSTS = setOf("10.0.2.2", "localhost", "127.0.0.1")

    fun isGroqKeyFormatValid(key: String): Boolean =
        key.length >= 20 && key.startsWith("gsk_") && key.none { it.isWhitespace() }

    fun isModelIdValid(model: String): Boolean = MODEL_ID_REGEX.matches(model)

    /** HTTPS everywhere; plain HTTP only for emulator/loopback hosts (exact host match, no prefix tricks). */
    fun isBackendUrlAllowed(url: String): Boolean {
        val uri = try {
            java.net.URI(url.trim())
        } catch (_: Exception) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false
        return when (uri.scheme?.lowercase()) {
            "https" -> true
            "http" -> host in LOCAL_HTTP_HOSTS
            else -> false
        }
    }
}
