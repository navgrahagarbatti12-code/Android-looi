package com.looi.ai.vision

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

interface ObjectDetectionListener {
    fun onObjectsDetected(objects: List<DetectedObject>, primaryLabel: String?)
}

/**
 * On-device ML Kit Object Detection analyzer.
 * Identifies physical surroundings without sending raw video to cloud.
 */
class ObjectDetectionAnalyzer(
    private val listener: ObjectDetectionListener
) : ImageAnalysis.Analyzer {

    private val detector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .enableMultipleObjects()
            .build()
    )

    private var frameSkipCounter = 0

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        // Run object detection every 3rd frame to optimize device battery & thermal budget
        frameSkipCounter++
        if (frameSkipCounter % 3 != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val inputImage = InputImage.fromMediaImage(
            mediaImage,
            imageProxy.imageInfo.rotationDegrees
        )

        detector.process(inputImage)
            .addOnSuccessListener { detectedObjects ->
                var dominantLabel: String? = null
                var maxConfidence = 0.5f

                for (obj in detectedObjects) {
                    for (label in obj.labels) {
                        if (label.confidence > maxConfidence) {
                            maxConfidence = label.confidence
                            dominantLabel = label.text
                        }
                    }
                }

                listener.onObjectsDetected(detectedObjects, dominantLabel)
            }
            .addOnFailureListener {
                listener.onObjectsDetected(emptyList(), null)
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    fun close() {
        try {
            detector.close()
        } catch (_: Exception) {
        }
    }
}
