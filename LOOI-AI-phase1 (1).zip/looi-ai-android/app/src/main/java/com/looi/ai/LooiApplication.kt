package com.looi.ai

import android.app.Application
import com.looi.ai.memory.MemoryRepository
import com.looi.ai.memory.database.AppDatabase
import com.looi.ai.settings.SettingsManager

class LooiApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val memoryRepository: MemoryRepository by lazy { MemoryRepository(database.conversationDao(), database.memoryDao()) }
    val settingsManager: SettingsManager by lazy { SettingsManager(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: LooiApplication
            private set
    }
}
