package com.looi.ai.vision

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.utils.SmoothingFilter

interface FaceTrackingListener {
    fun onFaceTracked(lookX: Float, lookY: Float, emotion: RobotEmotion, face: Face)
    fun onFaceLost()
}

/**
 * Real-time ML Kit Face Detection analyzer.
 * Calculates normalized gaze coordinates (-1 to 1) and infers expressions
 * (smile, curious, surprised, sleepy).
 */
class FaceTrackingAnalyzer(
    private val listener: FaceTrackingListener
) : ImageAnalysis.Analyzer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setMinFaceSize(0.15f)
            .build()
    )

    private val smoothX = SmoothingFilter(0.35f)
    private val smoothY = SmoothingFilter(0.35f)

    private var consecutiveLostFrames = 0
    private val lostThreshold = 8

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        val frameWidth = if (rotation == 90 || rotation == 270) {
            mediaImage.height.toFloat()
        } else {
            mediaImage.width.toFloat()
        }
        val frameHeight = if (rotation == 90 || rotation == 270) {
            mediaImage.width.toFloat()
        } else {
            mediaImage.height.toFloat()
        }

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (faces.isNotEmpty()) {
                    consecutiveLostFrames = 0
                    val face = faces[0]
                    val boundingBox = face.boundingBox

                    // Normalized face center (-1.0 to 1.0)
                    // Note: Front camera is mirrored horizontally
                    val rawCenterX = ((boundingBox.centerX() / frameWidth) - 0.5f) * -2f
                    val rawCenterY = ((boundingBox.centerY() / frameHeight) - 0.5f) * 2f

                    val filteredX = smoothX.filter(rawCenterX)
                    val filteredY = smoothY.filter(rawCenterY)

                    // Expression estimation
                    val smileProb = face.smilingProbability ?: 0f
                    val leftEyeOpen = face.leftEyeOpenProbability ?: 1f
                    val rightEyeOpen = face.rightEyeOpenProbability ?: 1f
                    val headEulerY = face.headEulerAngleY // Turn left/right
                    val headEulerZ = face.headEulerAngleZ // Tilt

                    val emotion = when {
                        smileProb > 0.65f -> RobotEmotion.HAPPY
                        leftEyeOpen < 0.2f && rightEyeOpen < 0.2f -> RobotEmotion.SLEEPING
                        leftEyeOpen < 0.35f || rightEyeOpen < 0.35f -> RobotEmotion.CURIOUS
                        Math.abs(headEulerZ) > 18f -> RobotEmotion.CURIOUS
                        else -> RobotEmotion.HAPPY
                    }

                    listener.onFaceTracked(filteredX, filteredY, emotion, face)
                } else {
                    consecutiveLostFrames++
                    if (consecutiveLostFrames >= lostThreshold) {
                        listener.onFaceLost()
                    }
                }
            }
            .addOnFailureListener {
                listener.onFaceLost()
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }
}
