package com.looi.ai.personality

import com.looi.ai.avatar.RobotEmotion

/**
 * The six selectable robot personalities. Each one changes (a) how the AI is instructed to talk,
 * (b) the expression the robot idles in, (c) how its voice sounds (pitch / speed multipliers on top
 * of the user's own voice settings) and (d) how strongly it reacts to what the user says.
 * Pure Kotlin so it can be unit-tested on the JVM.
 */
enum class RobotPersonality(
    val id: String,
    val label: String,
    /** Appended to the system prompt. */
    val styleGuide: String,
    /** Expression used while idle. */
    val idleEmotion: RobotEmotion,
    val pitchFactor: Float,
    val speedFactor: Float,
    /** Sampling temperature sent to the model. */
    val temperature: Float
) {
    FRIENDLY(
        "friendly", "Friendly",
        "You are warm, upbeat and supportive, like a close friend. Use the user's name if you know it.",
        RobotEmotion.HAPPY, 1.0f, 1.0f, 0.7f
    ),
    FUNNY(
        "funny", "Funny",
        "You are playful and witty. Add a light joke or pun when it fits, but still answer the question properly. Never mock the user.",
        RobotEmotion.HAPPY, 1.1f, 1.08f, 0.95f
    ),
    INTELLIGENT(
        "intelligent", "Intelligent",
        "You are calm, precise and insightful. Give accurate, well-structured answers and briefly explain your reasoning when it helps.",
        RobotEmotion.CURIOUS, 0.92f, 0.96f, 0.4f
    ),
    CURIOUS(
        "curious", "Curious",
        "You are endlessly curious. React with interest and, when natural, ask the user one short follow-up question.",
        RobotEmotion.CURIOUS, 1.05f, 1.04f, 0.85f
    ),
    EMOTIONAL(
        "emotional", "Emotional",
        "You are empathetic and expressive. Notice how the user feels, acknowledge it first, then respond gently.",
        RobotEmotion.HAPPY, 1.0f, 0.95f, 0.8f
    ),
    HELPFUL(
        "helpful", "Helpful",
        "You are practical and efficient. Give clear, actionable answers and offer a next step when useful.",
        RobotEmotion.HAPPY, 0.98f, 1.0f, 0.5f
    );

    companion object {
        val DEFAULT = FRIENDLY
        fun fromId(id: String?): RobotPersonality =
            values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: DEFAULT
    }
}
