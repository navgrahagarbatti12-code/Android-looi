package com.looi.ai.memory

import com.looi.ai.memory.database.ConversationDao
import com.looi.ai.memory.database.ConversationEntity
import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val conversationDao: ConversationDao) {

    val allConversations: Flow<List<ConversationEntity>> = conversationDao.getAllMessages()

    suspend fun recordUserMessage(text: String, emotion: String? = null) {
        conversationDao.insertMessage(
            ConversationEntity(
                sender = "USER",
                messageText = text,
                detectedEmotion = emotion
            )
        )
    }

    suspend fun recordLooiResponse(text: String) {
        conversationDao.insertMessage(
            ConversationEntity(
                sender = "LOOI",
                messageText = text
            )
        )
    }

    suspend fun getRecentContextSummary(): String {
        val recents = conversationDao.getRecentContext()
        if (recents.isEmpty()) return "No prior history."
        return recents.reversed().joinToString("\n") { "${it.sender}: ${it.messageText}" }
    }

    suspend fun clearMemory() {
        conversationDao.clearAll()
    }
}
