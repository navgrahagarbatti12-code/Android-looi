package com.looi.ai.memory

import com.looi.ai.ai.brain.ChatMessage
import com.looi.ai.ai.brain.MemoryCategory
import com.looi.ai.ai.brain.MemoryRanker
import com.looi.ai.ai.brain.RankableMemory
import com.looi.ai.ai.brain.SensitiveDataFilter
import com.looi.ai.memory.database.ConversationDao
import com.looi.ai.memory.database.ConversationEntity
import com.looi.ai.memory.database.MemoryDao
import com.looi.ai.memory.database.MemoryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MemorySaveResult { SAVED, DUPLICATE, SENSITIVE, INVALID }

/** Recent chat turns (oldest first) plus the timestamp of the oldest one. */
data class RecentWindow(val messages: List<ChatMessage>, val oldestTimestamp: Long)

class MemoryRepository(
    private val conversationDao: ConversationDao,
    private val memoryDao: MemoryDao
) {

    private val writeLock = Mutex()

    val allConversations: Flow<List<ConversationEntity>> = conversationDao.getAllMessages()
    val allMemories: Flow<List<MemoryEntity>> = memoryDao.observeAll()

    // ---------------------------------------------------------------- conversations

    suspend fun recordUserMessage(text: String, emotion: String? = null) {
        insertIfNew(ConversationEntity(sender = "USER", messageText = text, detectedEmotion = emotion))
    }

    suspend fun recordLooiResponse(text: String) {
        insertIfNew(ConversationEntity(sender = "LOOI", messageText = text))
    }

    /** Skips an identical message from the same sender saved within the last few seconds (double-tap/retry). */
    private suspend fun insertIfNew(entity: ConversationEntity) = writeLock.withLock {
        val text = entity.messageText.trim()
        if (text.isEmpty()) return@withLock
        val last = conversationDao.getLastMessage()
        val isDuplicate = last != null &&
            last.sender == entity.sender &&
            last.messageText == text &&
            entity.timestamp - last.timestamp < DUPLICATE_WINDOW_MS
        if (!isDuplicate) {
            conversationDao.insertMessage(entity.copy(messageText = text))
        }
    }

    /** Oldest-to-newest transcript of the last messages, or "No prior history." when the DB is empty. */
    suspend fun getRecentContextSummary(): String {
        val recents = conversationDao.getRecentContext(CONTEXT_LIMIT)
        if (recents.isEmpty()) return NO_HISTORY
        return recents.reversed().joinToString("\n") { "${it.sender}: ${it.messageText}" }
    }

    /** The last [limit] messages as chat turns, oldest first. */
    suspend fun recentWindow(limit: Int = CONTEXT_LIMIT): RecentWindow {
        val recents = conversationDao.getRecentContext(limit).reversed()
        val msgs = recents.map {
            ChatMessage(if (it.sender == "LOOI") ChatMessage.ASSISTANT else ChatMessage.USER, it.messageText)
        }
        return RecentWindow(msgs, recents.firstOrNull()?.timestamp ?: Long.MAX_VALUE)
    }

    /**
     * Older conversation lines related to [topic] (not part of the recent window), for "recall previous
     * conversations". Uses the three most distinctive words of the topic.
     */
    suspend fun recallSnippets(topic: String, before: Long, limit: Int = 3): List<String> {
        val keywords = MemoryRanker.tokenize(topic).sortedByDescending { it.length }.take(3)
        if (keywords.isEmpty()) return emptyList()
        val found = LinkedHashMap<Long, ConversationEntity>()
        for (k in keywords) {
            conversationDao.searchBefore(SqlLike.escape(k), before, limit).forEach { found.putIfAbsent(it.id, it) }
        }
        return found.values.sortedByDescending { it.timestamp }.take(limit).map { formatSnippet(it) }
    }

    suspend fun searchConversations(query: String, limit: Int = 30): List<ConversationEntity> {
        val q = SqlLike.escape(query)
        return if (q.isEmpty()) emptyList() else conversationDao.search(q, limit)
    }

    /** Newest saved messages first (Memory Vault "Old chats" tab with an empty search box). */
    suspend fun searchRecent(limit: Int = 100): List<ConversationEntity> = conversationDao.getRecentContext(limit)

    suspend fun deleteMessage(id: Long) {
        conversationDao.deleteById(id)
    }

    suspend fun clearMemory() {
        conversationDao.clearAll()
    }

    // ---------------------------------------------------------------- long-term memories

    /** Saves a user-approved memory. Secrets are refused; exact duplicates only refresh the timestamp. */
    suspend fun addMemory(text: String, source: String): MemorySaveResult = writeLock.withLock {
        val content = text.trim().replace(Regex("\\s+"), " ")
        if (content.length < MIN_MEMORY_CHARS || content.length > MAX_MEMORY_CHARS) return@withLock MemorySaveResult.INVALID
        if (SensitiveDataFilter.isSensitive(content)) return@withLock MemorySaveResult.SENSITIVE

        val existing = memoryDao.findExact(content)
        if (existing != null) {
            memoryDao.update(existing.copy(updatedAt = System.currentTimeMillis()))
            return@withLock MemorySaveResult.DUPLICATE
        }
        val overflow = memoryDao.count() - (MAX_MEMORIES - 1)
        if (overflow > 0) memoryDao.deleteOldest(overflow)
        memoryDao.insert(
            MemoryEntity(content = content, category = MemoryCategory.categorize(content), source = source)
        )
        MemorySaveResult.SAVED
    }

    suspend fun getRankableMemories(): List<RankableMemory> =
        memoryDao.getAll().map { RankableMemory(it.id, it.content, it.category, it.updatedAt) }

    suspend fun getAllMemories(): List<MemoryEntity> = memoryDao.getAll()

    suspend fun searchMemories(query: String, limit: Int = 30): List<MemoryEntity> {
        val q = SqlLike.escape(query)
        return if (q.isEmpty()) emptyList() else memoryDao.search(q, limit)
    }

    /** Deletes every memory containing [text]; returns how many were removed. */
    suspend fun forgetMatching(text: String): Int {
        val q = SqlLike.escape(text)
        return if (q.isEmpty()) 0 else memoryDao.deleteMatching(q)
    }

    suspend fun deleteMemory(id: Long) {
        memoryDao.deleteById(id)
    }

    suspend fun clearMemories() {
        memoryDao.clearAll()
    }

    private fun formatSnippet(e: ConversationEntity): String {
        val date = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(e.timestamp))
        return "${e.sender} ($date): ${e.messageText.take(160)}"
    }

    companion object {
        const val NO_HISTORY = "No prior history."
        const val SOURCE_COMMAND = "USER_COMMAND"
        const val SOURCE_APPROVED = "APPROVED_SUGGESTION"
        const val SOURCE_MANUAL = "MANUAL"
        private const val CONTEXT_LIMIT = 10
        private const val DUPLICATE_WINDOW_MS = 3_000L
        private const val MIN_MEMORY_CHARS = 3
        private const val MAX_MEMORY_CHARS = 300
        private const val MAX_MEMORIES = 200
    }
}
