package com.looi.ai.avatar

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import com.looi.ai.utils.SmoothingFilter
import kotlin.math.*
import kotlin.random.Random

/**
 * Custom Kotlin Canvas View for LOOI AI's expressive robot face avatar.
 * Features two large glowing eyes positioned far apart, natural random blinking,
 * smooth synchronized pupil tracking, smooth emotion transitions, idle breathing,
 * and sleeping/waking animations. Eyes blink vertically and never spin.
 */
class RobotFaceCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var currentEmotion: RobotEmotion = RobotEmotion.HAPPY
        set(value) {
            if (field != value) {
                val previous = field
                field = value
                if (value != RobotEmotion.SLEEPING) {
                    isWakingUp = true
                }
                // Waking up: eyes "pop" slightly wider for a moment, then settle.
                if (previous == RobotEmotion.SLEEPING && value != RobotEmotion.SLEEPING) {
                    wakePulse = 1f
                }
                invalidate()
            }
        }

    var animationSpeedMultiplier: Float = 1.0f
        set(value) {
            field = value.coerceIn(0.4f, 2.0f)
            val gazeAlpha = (0.18f * field).coerceIn(0.06f, 0.45f)
            lookXFilter.alpha = gazeAlpha
            lookYFilter.alpha = gazeAlpha
        }

    // Pupil look offsets normalized (-1.0f to 1.0f)
    private var targetLookX = 0f
    private var targetLookY = 0f
    private var currentLookX = 0f
    private var currentLookY = 0f

    // Natural idle behaviour: glances happen only when no face is being tracked
    private var lastLookInputMs = 0L
    private var nextIdleGlanceMs = 0L
    private var wakePulse = 0f

    private val lookXFilter = SmoothingFilter(0.18f)
    private val lookYFilter = SmoothingFilter(0.18f)

    // Smoothly interpolated emotion parameters
    private val eyeScaleXFilter = SmoothingFilter(0.15f)
    private val eyeScaleYFilter = SmoothingFilter(0.15f)
    private val leftTiltFilter = SmoothingFilter(0.15f)
    private val rightTiltFilter = SmoothingFilter(0.15f)
    private val sleepBlendFilter = SmoothingFilter(0.10f)

    private var smoothScaleX = 1.0f
    private var smoothScaleY = 1.0f
    private var smoothLeftTilt = 0f
    private var smoothRightTilt = 0f
    private var sleepBlend = 0f
    private var isWakingUp = false

    // Eyelid blink factor (0.0f = wide open, 1.0f = completely closed)
    private var blinkProgress = 0f
    private var isBlinking = false
    private var blinkAnimator: ValueAnimator? = null

    // Mouth lip-sync amplitude (0.0f to 1.0f)
    var mouthAmplitude: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            postInvalidateOnAnimation()
        }

    // Pre-allocated Paint objects (no allocations in onDraw)
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.FILL
    }

    private val eyeGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#554FACFE")
        style = Paint.Style.STROKE
        strokeWidth = 10f
    }

    private val darkIrisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0A364A")
        style = Paint.Style.FILL
    }

    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val darkBackgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#080C14")
        style = Paint.Style.FILL
    }

    private val eyebrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8")
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    private val mouthFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.FILL
    }

    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FF4B72")
        style = Paint.Style.FILL
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6038BDF8")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.FILL
    }

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    private val sleepZPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textSize = 36f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    // Pre-allocated geometry helpers
    private val eyeRect = RectF()
    private val mouthRect = RectF()
    private val clipPath = Path()
    private val browPath = Path()
    private val mouthPath = Path()
    private val sleepArcPath = Path()

    // Animation loop timer
    private var animationTime = 0f
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tickerAnimator: ValueAnimator? = null

    private val blinkRunnable = object : Runnable {
        override fun run() {
            triggerBlink()
            val minDelay = (2200f / animationSpeedMultiplier).toLong().coerceAtLeast(1200L)
            val maxDelay = (5200f / animationSpeedMultiplier).toLong().coerceAtLeast(2500L)
            // About 1 in 7 blinks is a quick double blink, like a real eye.
            if (Random.nextFloat() < 0.14f) mainHandler.postDelayed(doubleBlinkRunnable, 260L)
            val nextBlinkDelay = Random.nextLong(minDelay, maxDelay)
            mainHandler.postDelayed(this, nextBlinkDelay)
        }
    }

    private val doubleBlinkRunnable = Runnable { triggerBlink() }

    private fun startAnimations() {
        stopAnimations()
        mainHandler.postDelayed(blinkRunnable, 1800)

        tickerAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 16
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                animationTime += 0.045f * animationSpeedMultiplier
                updateStateTransitions()
                postInvalidateOnAnimation()
            }
            start()
        }
    }

    private fun stopAnimations() {
        mainHandler.removeCallbacks(blinkRunnable)
        mainHandler.removeCallbacks(doubleBlinkRunnable)
        tickerAnimator?.cancel()
        tickerAnimator = null
        blinkAnimator?.cancel()
        blinkAnimator = null
        isBlinking = false
        blinkProgress = 0f
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // Restart after a detach/re-attach; otherwise eyes freeze permanently
        startAnimations()
    }

    fun setLookTarget(x: Float, y: Float) {
        lastLookInputMs = SystemClock.uptimeMillis()
        targetLookX = x.coerceIn(-1f, 1f)
        targetLookY = y.coerceIn(-1f, 1f)
    }

    fun wakeUp() {
        if (currentEmotion == RobotEmotion.SLEEPING) {
            currentEmotion = RobotEmotion.HAPPY
            triggerBlink()
        }
    }

    fun goToSleep() {
        currentEmotion = RobotEmotion.SLEEPING
    }

    private fun updateStateTransitions() {
        // Gentle autonomous idle glance when searching or sleeping
        when (currentEmotion) {
            RobotEmotion.SEARCHING -> {
                targetLookX = (sin(animationTime * 0.55f) * 0.65f).coerceIn(-1f, 1f)
                targetLookY = (cos(animationTime * 0.4f) * 0.22f).coerceIn(-1f, 1f)
            }
            RobotEmotion.SLEEPING -> {
                targetLookX = 0f
                targetLookY = 0.25f
            }
            RobotEmotion.THINKING -> if (!isTrackingFace()) {
                // Looks up and to the side while "thinking"
                targetLookX = -0.55f
                targetLookY = -0.5f
            }
            RobotEmotion.LISTENING -> if (!isTrackingFace()) {
                targetLookX = 0f
                targetLookY = 0f
            }
            else -> updateIdleGlance(if (currentEmotion == RobotEmotion.TALKING) 0.5f else 1f)
        }
        wakePulse = if (wakePulse < 0.01f) 0f else wakePulse * 0.93f

        // Smooth synchronized eye gaze
        currentLookX = lookXFilter.filter(targetLookX)
        currentLookY = lookYFilter.filter(targetLookY)

        // Smooth expression transitions
        val targetScaleX = when (currentEmotion) {
            RobotEmotion.SURPRISED -> 1.14f
            RobotEmotion.CURIOUS -> 1.05f
            else -> 1.0f
        }
        val targetScaleY = when (currentEmotion) {
            RobotEmotion.SURPRISED -> 1.22f
            RobotEmotion.SAD -> 0.78f
            RobotEmotion.ANGRY -> 0.72f
            RobotEmotion.HAPPY -> 0.96f
            else -> 1.0f
        }
        val (targetLeftTilt, targetRightTilt) = when (currentEmotion) {
            RobotEmotion.ANGRY -> Pair(18f, -18f)
            RobotEmotion.SAD -> Pair(-16f, 16f)
            RobotEmotion.SURPRISED -> Pair(-10f, -10f)
            RobotEmotion.CURIOUS -> Pair(-14f, 6f)
            else -> Pair(0f, 0f)
        }
        val targetSleep = if (currentEmotion == RobotEmotion.SLEEPING) 1f else 0f

        smoothScaleX = eyeScaleXFilter.filter(targetScaleX)
        smoothScaleY = eyeScaleYFilter.filter(targetScaleY)
        smoothLeftTilt = leftTiltFilter.filter(targetLeftTilt)
        smoothRightTilt = rightTiltFilter.filter(targetRightTilt)
        sleepBlend = sleepBlendFilter.filter(targetSleep)

        if (isWakingUp && sleepBlend < 0.05f) {
            isWakingUp = false
        }
    }

    /** True while the camera is feeding fresh face positions (setLookTarget called recently). */
    private fun isTrackingFace(): Boolean = SystemClock.uptimeMillis() - lastLookInputMs < 1500L

    /** Occasional small eye movements (saccades) so the robot never stares frozen. */
    private fun updateIdleGlance(amplitude: Float) {
        if (isTrackingFace()) return
        val now = SystemClock.uptimeMillis()
        if (now < nextIdleGlanceMs) return
        nextIdleGlanceMs = now + Random.nextLong(1400L, 4200L)
        if (Random.nextFloat() < 0.3f) {
            targetLookX = 0f
            targetLookY = 0f
        } else {
            targetLookX = (Random.nextFloat() - 0.5f) * 1.1f * amplitude
            targetLookY = (Random.nextFloat() - 0.5f) * 0.6f * amplitude
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        // No animation work while the app is in the background or the screen is off (battery).
        if (visibility == VISIBLE) {
            if (isAttachedToWindow) startAnimations()
        } else {
            stopAnimations()
        }
    }

    fun triggerBlink() {
        if (isBlinking || currentEmotion == RobotEmotion.SLEEPING) return
        blinkAnimator?.cancel()
        isBlinking = true
        blinkAnimator = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = (190f / animationSpeedMultiplier).toLong().coerceIn(110L, 320L)
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                blinkProgress = anim.animatedValue as Float
                postInvalidateOnAnimation()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    isBlinking = false
                    blinkProgress = 0f
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Deep dark robot screen background
        canvas.drawRect(0f, 0f, w, h, darkBackgroundPaint)

        val centerX = w / 2f
        val centerY = h / 2f - h * 0.03f

        // Two large glowing eyes positioned far apart
        val eyeSpacing = min(w * 0.27f, h * 0.28f)
        val eyeRadiusX = min(w * 0.145f, h * 0.13f)
        val eyeRadiusY = eyeRadiusX * 1.24f

        val leftEyeCenterX = centerX - eyeSpacing
        val rightEyeCenterX = centerX + eyeSpacing

        // Subtle idle breathing bounce
        val bounceAmplitude = if (currentEmotion == RobotEmotion.SLEEPING) 2.5f else 5.5f
        val bounceY = sin(animationTime * 1.3f) * bounceAmplitude
        val eyeCenterY = centerY + bounceY

        // 1. Cheeks / Blush when happy or talking
        if (currentEmotion == RobotEmotion.HAPPY || currentEmotion == RobotEmotion.TALKING) {
            val blushRadius = eyeRadiusX * 0.52f
            canvas.drawCircle(
                leftEyeCenterX - eyeRadiusX * 0.85f,
                eyeCenterY + eyeRadiusY * 0.85f,
                blushRadius,
                blushPaint
            )
            canvas.drawCircle(
                rightEyeCenterX + eyeRadiusX * 0.85f,
                eyeCenterY + eyeRadiusY * 0.85f,
                blushRadius,
                blushPaint
            )
        }

        // 2. Eyebrows (fade out during sleep)
        if (sleepBlend < 0.85f) {
            eyebrowPaint.alpha = ((1f - sleepBlend) * 255).toInt().coerceIn(0, 255)
            drawEyebrows(canvas, leftEyeCenterX, rightEyeCenterX, eyeCenterY - eyeRadiusY * 1.18f, eyeRadiusX)
        }

        // 3. Left & Right Eyes (move together naturally, blink vertically)
        drawSingleEye(canvas, leftEyeCenterX, eyeCenterY, eyeRadiusX, eyeRadiusY)
        drawSingleEye(canvas, rightEyeCenterX, eyeCenterY, eyeRadiusX, eyeRadiusY)

        // 4. Floating Zzz when sleeping
        if (sleepBlend > 0.5f) {
            val zOffset = (animationTime * 14f) % 45f
            sleepZPaint.alpha = (sleepBlend * (1f - zOffset / 45f) * 220).toInt().coerceIn(0, 255)
            canvas.drawText("Z", rightEyeCenterX + eyeRadiusX * 0.7f, eyeCenterY - eyeRadiusY - zOffset, sleepZPaint)
            canvas.drawText("z", rightEyeCenterX + eyeRadiusX * 1.05f, eyeCenterY - eyeRadiusY - zOffset * 0.6f - 18f, sleepZPaint)
        }

        // 5. Animated Mouth
        drawMouth(canvas, centerX, eyeCenterY + eyeRadiusY * 1.42f, eyeRadiusX)

        // 6. Thinking / Listening Overlays
        if (currentEmotion == RobotEmotion.THINKING) {
            drawThinkingOrbits(canvas, centerX, eyeCenterY, eyeSpacing * 1.65f)
        } else if (currentEmotion == RobotEmotion.LISTENING) {
            drawListeningWaves(canvas, centerX, eyeCenterY + eyeRadiusY * 1.95f)
        }
    }

    private fun drawSingleEye(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        rx: Float,
        ry: Float
    ) {
        canvas.save()

        // Sleeping arc when fully asleep
        if (sleepBlend > 0.85f) {
            sleepArcPath.reset()
            sleepArcPath.moveTo(cx - rx * 0.8f, cy)
            sleepArcPath.quadTo(cx, cy + ry * 0.38f, cx + rx * 0.8f, cy)
            eyebrowPaint.alpha = 255
            eyebrowPaint.strokeWidth = 11f
            canvas.drawPath(sleepArcPath, eyebrowPaint)
            canvas.restore()
            return
        }

        val openFactor = (1.0f - blinkProgress) * (1.0f - sleepBlend)
        val effectiveScaleY = max(0.06f, smoothScaleY * (1f + 0.14f * wakePulse) * openFactor)

        eyeRect.set(
            cx - rx * smoothScaleX,
            cy - ry * effectiveScaleY,
            cx + rx * smoothScaleX,
            cy + ry * effectiveScaleY
        )

        // Outer neon glow & main cyan sclera
        canvas.drawOval(eyeRect, eyeGlowPaint)
        canvas.drawOval(eyeRect, eyePaint)

        // Clip to eye bounds so pupil stays neatly inside
        clipPath.reset()
        clipPath.addOval(eyeRect, Path.Direction.CW)
        canvas.clipPath(clipPath)

        // Synchronized pupil tracking
        val maxPupilShiftX = rx * 0.42f
        val maxPupilShiftY = ry * 0.36f
        val pupilCenterX = cx + currentLookX * maxPupilShiftX
        val pupilCenterY = cy + currentLookY * maxPupilShiftY
        val pupilRadius = rx * 0.40f

        canvas.drawCircle(pupilCenterX, pupilCenterY, pupilRadius * 1.12f, darkIrisPaint)
        canvas.drawCircle(pupilCenterX, pupilCenterY, pupilRadius * 0.72f, pupilPaint)

        // Catch-light highlights
        canvas.drawCircle(
            pupilCenterX - pupilRadius * 0.34f,
            pupilCenterY - pupilRadius * 0.34f,
            pupilRadius * 0.26f,
            highlightPaint
        )
        canvas.drawCircle(
            pupilCenterX + pupilRadius * 0.32f,
            pupilCenterY + pupilRadius * 0.28f,
            pupilRadius * 0.13f,
            highlightPaint
        )

        canvas.restore()
    }

    private fun drawEyebrows(
        canvas: Canvas,
        leftX: Float,
        rightX: Float,
        y: Float,
        rx: Float
    ) {
        val browWidth = rx * 0.88f
        eyebrowPaint.strokeWidth = 9f

        browPath.reset()
        browPath.moveTo(leftX - browWidth / 2f, y + smoothLeftTilt)
        browPath.quadTo(leftX, y - 8f, leftX + browWidth / 2f, y - smoothLeftTilt)
        canvas.drawPath(browPath, eyebrowPaint)

        browPath.reset()
        browPath.moveTo(rightX - browWidth / 2f, y - smoothRightTilt)
        browPath.quadTo(rightX, y - 8f, rightX + browWidth / 2f, y + smoothRightTilt)
        canvas.drawPath(browPath, eyebrowPaint)
    }

    private fun drawMouth(canvas: Canvas, cx: Float, cy: Float, rx: Float) {
        val mouthWidth = rx * 0.9f

        when (currentEmotion) {
            RobotEmotion.HAPPY -> {
                mouthPath.reset()
                mouthPath.moveTo(cx - mouthWidth * 0.6f, cy)
                mouthPath.quadTo(cx, cy + 26f, cx + mouthWidth * 0.6f, cy)
                canvas.drawPath(mouthPath, mouthPaint)
            }
            RobotEmotion.TALKING -> {
                val openHeight = 12f + mouthAmplitude * 38f
                mouthRect.set(
                    cx - mouthWidth * 0.5f,
                    cy - openHeight * 0.5f,
                    cx + mouthWidth * 0.5f,
                    cy + openHeight * 0.5f
                )
                canvas.drawOval(mouthRect, mouthFillPaint)
            }
            RobotEmotion.SURPRISED -> {
                canvas.drawCircle(cx, cy + 6f, 18f, mouthPaint)
            }
            RobotEmotion.SAD -> {
                mouthPath.reset()
                mouthPath.moveTo(cx - mouthWidth * 0.5f, cy + 16f)
                mouthPath.quadTo(cx, cy - 2f, cx + mouthWidth * 0.5f, cy + 16f)
                canvas.drawPath(mouthPath, mouthPaint)
            }
            RobotEmotion.ANGRY -> {
                canvas.drawLine(cx - mouthWidth * 0.45f, cy + 8f, cx + mouthWidth * 0.45f, cy + 8f, mouthPaint)
            }
            RobotEmotion.SLEEPING -> {
                canvas.drawLine(cx - 16f, cy + 6f, cx + 16f, cy + 6f, mouthPaint)
            }
            else -> {
                mouthPath.reset()
                mouthPath.moveTo(cx - mouthWidth * 0.42f, cy)
                mouthPath.quadTo(cx + 6f, cy + 14f, cx + mouthWidth * 0.42f, cy + 2f)
                canvas.drawPath(mouthPath, mouthPaint)
            }
        }
    }

    private fun drawThinkingOrbits(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        canvas.drawCircle(cx, cy, radius, orbitPaint)
        val dotAngle = animationTime * 2.5f
        val dotX = cx + cos(dotAngle) * radius
        val dotY = cy + sin(dotAngle) * radius
        canvas.drawCircle(dotX, dotY, 9f, dotPaint)
    }

    private fun drawListeningWaves(canvas: Canvas, cx: Float, cy: Float) {
        val barCount = 7
        val barSpacing = 18f
        val startX = cx - (barCount - 1) * barSpacing / 2f

        for (i in 0 until barCount) {
            val barX = startX + i * barSpacing
            val waveHeight = 8f + sin(animationTime * 4f + i * 0.8f).absoluteValue * 28f
            canvas.drawLine(barX, cy - waveHeight / 2f, barX, cy + waveHeight / 2f, wavePaint)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopAnimations()
    }
}
