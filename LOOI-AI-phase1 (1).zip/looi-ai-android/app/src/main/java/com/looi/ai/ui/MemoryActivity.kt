package com.looi.ai.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.looi.ai.LooiApplication
import com.looi.ai.R
import com.looi.ai.databinding.ActivityMemoryBinding
import com.looi.ai.memory.MemoryRepository
import com.looi.ai.memory.MemorySaveResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Privacy dashboard for everything LOOI stores: view, search, add and delete long-term memories,
 * and search or delete saved conversation messages. Everything lives in the local Room database.
 */
class MemoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMemoryBinding
    private lateinit var repo: MemoryRepository
    private val adapter = RowAdapter()
    private var showingMemories = true
    private var loadJob: Job? = null
    private var searchJob: Job? = null
    private var dialog: AlertDialog? = null

    private data class Row(val id: Long, val title: String, val meta: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMemoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = LooiApplication.instance.memoryRepository

        setSupportActionBar(binding.toolbarMemory)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarMemory.setNavigationOnClickListener { finish() }

        binding.rvItems.adapter = adapter
        adapter.onDelete = { row -> confirmDelete(row) }

        binding.tabMemories.setOnClickListener { selectTab(true) }
        binding.tabChats.setOnClickListener { selectTab(false) }
        binding.btnAddMemory.setOnClickListener { showAddDialog() }
        binding.btnDeleteAll.setOnClickListener { confirmDeleteAll() }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(250) // debounce typing
                    refresh()
                }
            }
        })
        selectTab(true)
    }

    private fun selectTab(memories: Boolean) {
        showingMemories = memories
        val active = getColor(R.color.looi_cyan)
        val idle = 0xFF1E293B.toInt()
        binding.tabMemories.setBackgroundColor(if (memories) active else idle)
        binding.tabMemories.setTextColor(getColor(if (memories) R.color.looi_black else R.color.text_primary))
        binding.tabChats.setBackgroundColor(if (memories) idle else active)
        binding.tabChats.setTextColor(getColor(if (memories) R.color.text_primary else R.color.looi_black))
        binding.btnAddMemory.visibility = if (memories) View.VISIBLE else View.GONE
        binding.etSearch.hint = if (memories) "Search memories" else "Search old chats"
        refresh()
    }

    private fun refresh() {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            val query = binding.etSearch.text?.toString().orEmpty().trim()
            val fmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
            val rows: List<Row> = if (showingMemories) {
                val list = if (query.isEmpty()) repo.getAllMemories() else repo.searchMemories(query, 100)
                list.map { Row(it.id, it.content, "${it.category.lowercase()} · ${fmt.format(Date(it.updatedAt))}") }
            } else {
                val list = if (query.isEmpty()) repo.searchRecent(100) else repo.searchConversations(query, 100)
                list.map {
                    Row(it.id, it.messageText, "${if (it.sender == "LOOI") "LOOI" else "You"} · ${fmt.format(Date(it.timestamp))}")
                }
            }
            adapter.submit(rows)
            binding.tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            binding.tvEmpty.text = when {
                rows.isNotEmpty() -> ""
                query.isNotEmpty() -> "Nothing matches \"$query\"."
                showingMemories -> "No memories yet.\nSay \"remember that …\" to LOOI, or tap Add memory."
                else -> "No saved conversations."
            }
        }
    }

    private fun confirmDelete(row: Row) {
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle("Delete this ${if (showingMemories) "memory" else "message"}?")
            .setMessage(row.title.take(160))
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    if (showingMemories) repo.deleteMemory(row.id) else repo.deleteMessage(row.id)
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteAll() {
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle(if (showingMemories) "Delete ALL memories?" else "Delete ALL saved chats?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete all") { _, _ ->
                lifecycleScope.launch {
                    if (showingMemories) repo.clearMemories() else repo.clearMemory()
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddDialog() {
        val input = EditText(this).apply {
            hint = "e.g. My sister is called Riya"
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle("Add a memory")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                lifecycleScope.launch {
                    val msg = when (repo.addMemory(input.text.toString(), MemoryRepository.SOURCE_MANUAL)) {
                        MemorySaveResult.SAVED -> "Saved"
                        MemorySaveResult.DUPLICATE -> "Already saved"
                        MemorySaveResult.SENSITIVE -> "Not saved: looks private (password, OTP, card or ID)"
                        MemorySaveResult.INVALID -> "Use 3 to 300 characters"
                    }
                    Toast.makeText(this@MemoryActivity, msg, Toast.LENGTH_SHORT).show()
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        dialog?.dismiss()
        dialog = null
        searchJob?.cancel()
        loadJob?.cancel()
        super.onDestroy()
    }

    private class RowAdapter : RecyclerView.Adapter<RowAdapter.VH>() {
        private var rows: List<Row> = emptyList()
        var onDelete: ((Row) -> Unit)? = null

        fun submit(newRows: List<Row>) {
            rows = newRows
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
            LayoutInflater.from(parent.context).inflate(R.layout.item_memory, parent, false)
        )

        override fun onBindViewHolder(holder: VH, position: Int) {
            val row = rows[position]
            holder.title.text = row.title
            holder.meta.text = row.meta
            holder.delete.setOnClickListener { onDelete?.invoke(row) }
        }

        override fun getItemCount() = rows.size

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            val title: TextView = view.findViewById(R.id.tvMemoryTitle)
            val meta: TextView = view.findViewById(R.id.tvMemoryMeta)
            val delete: ImageButton = view.findViewById(R.id.btnDeleteItem)
        }
    }
}
