package com.looi.ai.memory.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One long-term memory the user approved (by command or by accepting an AI suggestion).
 * category: FACT, PREFERENCE or INSTRUCTION. source: USER_COMMAND, APPROVED_SUGGESTION or MANUAL.
 */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val category: String,
    val source: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
