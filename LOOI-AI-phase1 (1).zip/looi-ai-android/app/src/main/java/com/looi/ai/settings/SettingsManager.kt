package com.looi.ai.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persistent configuration manager for LOOI AI.
 * Stores sensitive API keys in Android Keystore-backed EncryptedSharedPreferences
 * and non-sensitive preferences in app-private SharedPreferences.
 */
class SettingsManager(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Last reason Keystore-backed storage was unavailable (null when it works). Never contains secrets. */
    @Volatile
    var secureStorageError: String? = null
        private set

    /** Session-only copy used ONLY when Keystore storage is unavailable. Never written to disk. */
    @Volatile
    private var sessionOnlyKey: String? = null

    /**
     * Keystore-backed encrypted storage, or null when the device cannot provide it.
     * There is deliberately NO fallback to plain-text SharedPreferences.
     */
    private val securePrefs: SharedPreferences? by lazy { createEncryptedPrefs(appContext) }

    val isSecureStorageAvailable: Boolean get() = securePrefs != null

    private fun createEncryptedPrefs(context: Context): SharedPreferences? {
        fun build(): SharedPreferences {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            return EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            build()
        } catch (first: Exception) {
            Log.e(TAG, "Encrypted storage failed (${first.javaClass.simpleName}); resetting corrupted secure file")
            try {
                // A restored backup / changed lock screen can leave an undecryptable file behind.
                context.deleteSharedPreferences(SECURE_PREFS_NAME)
                build()
            } catch (second: Exception) {
                secureStorageError = "Secure storage unavailable (${second.javaClass.simpleName})"
                Log.e(TAG, "Encrypted storage unavailable; API key will be kept in memory only", second)
                null
            }
        }
    }

    var aiProvider: String
        get() = prefs.getString(KEY_AI_PROVIDER, PROVIDER_AUTO) ?: PROVIDER_AUTO
        set(value) = prefs.edit().putString(KEY_AI_PROVIDER, value).apply()

    var groqApiKey: String
        get() {
            val secure = securePrefs
            val stored = secure?.getString(KEY_GROQ_API_KEY, null)?.trim()
            if (!stored.isNullOrEmpty()) return stored

            // One-time migration: move any legacy plain-text key into encrypted storage, then wipe it.
            val legacy = prefs.getString(KEY_GROQ_API_KEY, null)?.trim()
            if (!legacy.isNullOrEmpty()) {
                if (secure != null) {
                    secure.edit().putString(KEY_GROQ_API_KEY, legacy).apply()
                } else {
                    sessionOnlyKey = legacy
                }
                prefs.edit().remove(KEY_GROQ_API_KEY).apply()
                return legacy
            }
            return sessionOnlyKey.orEmpty()
        }
        set(value) {
            val trimmed = value.trim()
            // Plain-text copies are always removed, regardless of what happens below.
            prefs.edit().remove(KEY_GROQ_API_KEY).apply()
            val secure = securePrefs
            if (trimmed.isEmpty()) {
                secure?.edit()?.remove(KEY_GROQ_API_KEY)?.apply()
                sessionOnlyKey = null
            } else if (secure != null) {
                secure.edit().putString(KEY_GROQ_API_KEY, trimmed).apply()
                sessionOnlyKey = null
            } else {
                sessionOnlyKey = trimmed
            }
        }

    var groqModel: String
        get() {
            val saved = prefs.getString(KEY_GROQ_MODEL, DEFAULT_GROQ_MODEL)?.trim().orEmpty()
            // Models removed by Groq (e.g. mixtral-8x7b-32768) would fail forever
            return if (saved.isEmpty() || saved in RETIRED_GROQ_MODELS) DEFAULT_GROQ_MODEL else saved
        }
        set(value) = prefs.edit().putString(KEY_GROQ_MODEL, value.trim()).apply()

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, DEFAULT_BACKEND_URL)?.trim()?.trimEnd('/') ?: DEFAULT_BACKEND_URL
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim().trimEnd('/')).apply()

    fun isGroqKeyFormatValid(key: String): Boolean = InputValidators.isGroqKeyFormatValid(key)

    fun isModelIdValid(model: String): Boolean = InputValidators.isModelIdValid(model)

    /** HTTPS everywhere; plain HTTP only for emulator/loopback development hosts (exact host match). */
    fun isBackendUrlAllowedBySecurityPolicy(url: String): Boolean =
        InputValidators.isBackendUrlAllowed(url)

    /** True when the device currently has a validated internet connection. */
    fun isOnline(): Boolean {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    var languageCode: String
        get() = prefs.getString(KEY_LANGUAGE_CODE, "hi-IN") ?: "hi-IN"
        set(value) = prefs.edit().putString(KEY_LANGUAGE_CODE, value).apply()

    var voiceName: String
        get() = prefs.getString(KEY_VOICE_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_VOICE_NAME, value).apply()

    var speechSpeed: Float
        get() = prefs.getFloat(KEY_SPEECH_SPEED, 1.05f).coerceIn(0.5f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_SPEED, value.coerceIn(0.5f, 2.0f)).apply()

    var speechPitch: Float
        get() = prefs.getFloat(KEY_SPEECH_PITCH, 1.25f).coerceIn(0.6f, 1.8f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_PITCH, value.coerceIn(0.6f, 1.8f)).apply()

    var eyeAnimationSpeed: Float
        get() = prefs.getFloat(KEY_EYE_ANIM_SPEED, 1.0f).coerceIn(0.4f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_EYE_ANIM_SPEED, value.coerceIn(0.4f, 2.0f)).apply()

    var cameraEnabled: Boolean
        get() = prefs.getBoolean(KEY_CAMERA_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CAMERA_ENABLED, value).apply()

    var mirrorCamera: Boolean
        get() = prefs.getBoolean(KEY_MIRROR_CAMERA, true)
        set(value) = prefs.edit().putBoolean(KEY_MIRROR_CAMERA, value).apply()

    var objectDetectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_OBJECT_DETECTION, true)
        set(value) = prefs.edit().putBoolean(KEY_OBJECT_DETECTION, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var saveHistoryEnabled: Boolean
        get() = prefs.getBoolean(KEY_SAVE_HISTORY, true)
        set(value) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, value).apply()

    var personalityId: String
        get() = prefs.getString(KEY_PERSONALITY, "friendly") ?: "friendly"
        set(value) = prefs.edit().putString(KEY_PERSONALITY, value).apply()

    /** Master switch for saving/using long-term memories. Off = nothing is stored or injected. */
    var longTermMemoryEnabled: Boolean
        get() = prefs.getBoolean(KEY_LONG_TERM_MEMORY, true)
        set(value) = prefs.edit().putBoolean(KEY_LONG_TERM_MEMORY, value).apply()

    /** Lets the AI suggest memories; each one is only saved after the user taps Save. */
    var memoryProposalsEnabled: Boolean
        get() = prefs.getBoolean(KEY_MEMORY_PROPOSALS, true)
        set(value) = prefs.edit().putBoolean(KEY_MEMORY_PROPOSALS, value).apply()

    /** Extra model IDs fetched from Groq (kept so the spinner survives restarts). */
    var cachedGroqModels: List<String>
        get() = prefs.getString(KEY_CACHED_MODELS, "").orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }
        set(value) = prefs.edit().putString(KEY_CACHED_MODELS, value.joinToString(",")).apply()

    companion object {
        private const val TAG = "SettingsManager"
        private const val PREFS_NAME = "looi_ai_settings"
        private const val SECURE_PREFS_NAME = "looi_ai_secrets"
        private const val KEY_AI_PROVIDER = "ai_provider"
        private const val KEY_GROQ_API_KEY = "groq_api_key"
        private const val KEY_GROQ_MODEL = "groq_model"
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_LANGUAGE_CODE = "language_code"
        private const val KEY_VOICE_NAME = "voice_name"
        private const val KEY_SPEECH_SPEED = "speech_speed"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_EYE_ANIM_SPEED = "eye_anim_speed"
        private const val KEY_CAMERA_ENABLED = "camera_enabled"
        private const val KEY_MIRROR_CAMERA = "mirror_camera"
        private const val KEY_OBJECT_DETECTION = "object_detection"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_SAVE_HISTORY = "save_history"
        private const val KEY_PERSONALITY = "personality"
        private const val KEY_LONG_TERM_MEMORY = "long_term_memory"
        private const val KEY_MEMORY_PROPOSALS = "memory_proposals"
        private const val KEY_CACHED_MODELS = "cached_groq_models"

        const val PROVIDER_AUTO = "AUTO"
        const val PROVIDER_GROQ = "GROQ"
        const val PROVIDER_BACKEND = "BACKEND"

        private val RETIRED_GROQ_MODELS = setOf("mixtral-8x7b-32768", "gemma-7b-it", "llama3-70b-8192", "llama3-8b-8192")
        const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"
        const val DEFAULT_BACKEND_URL = "http://10.0.2.2:3000"
    }
}
