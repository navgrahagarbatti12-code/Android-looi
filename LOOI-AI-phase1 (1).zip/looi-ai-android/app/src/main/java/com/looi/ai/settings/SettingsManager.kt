package com.looi.ai.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persistent configuration manager for LOOI AI.
 * Stores sensitive API keys in Android Keystore-backed EncryptedSharedPreferences
 * and non-sensitive preferences in app-private SharedPreferences.
 */
class SettingsManager(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val securePrefs: SharedPreferences by lazy {
        createEncryptedPrefs(appContext)
    }

    private fun createEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e(TAG, "EncryptedSharedPreferences unavailable on device, falling back to private prefs", e)
            prefs
        }
    }

    var aiProvider: String
        get() = prefs.getString(KEY_AI_PROVIDER, PROVIDER_AUTO) ?: PROVIDER_AUTO
        set(value) = prefs.edit().putString(KEY_AI_PROVIDER, value).apply()

    var groqApiKey: String
        get() {
            val encrypted = securePrefs.getString(KEY_GROQ_API_KEY, null)?.trim()
            if (!encrypted.isNullOrEmpty()) return encrypted

            // Migrate any legacy plain-text key into encrypted storage and wipe the legacy entry
            val legacy = prefs.getString(KEY_GROQ_API_KEY, null)?.trim()
            if (!legacy.isNullOrEmpty()) {
                securePrefs.edit().putString(KEY_GROQ_API_KEY, legacy).apply()
                if (securePrefs !== prefs) {
                    prefs.edit().remove(KEY_GROQ_API_KEY).apply()
                }
                return legacy
            }
            return ""
        }
        set(value) {
            val trimmed = value.trim()
            if (trimmed.isEmpty()) {
                securePrefs.edit().remove(KEY_GROQ_API_KEY).apply()
            } else {
                securePrefs.edit().putString(KEY_GROQ_API_KEY, trimmed).apply()
            }
            if (securePrefs !== prefs && prefs.contains(KEY_GROQ_API_KEY)) {
                prefs.edit().remove(KEY_GROQ_API_KEY).apply()
            }
        }

    var groqModel: String
        get() {
            val saved = prefs.getString(KEY_GROQ_MODEL, DEFAULT_GROQ_MODEL)?.trim().orEmpty()
            // Models removed by Groq (e.g. mixtral-8x7b-32768) would return HTTP 400/404 forever
            return if (saved.isEmpty() || saved in RETIRED_GROQ_MODELS) DEFAULT_GROQ_MODEL else saved
        }
        set(value) = prefs.edit().putString(KEY_GROQ_MODEL, value).apply()

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, DEFAULT_BACKEND_URL)?.trim()?.trimEnd('/') ?: DEFAULT_BACKEND_URL
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim().trimEnd('/')).apply()

    fun isBackendUrlAllowedBySecurityPolicy(url: String): Boolean {
        val normalized = url.trim().lowercase()
        if (normalized.startsWith("https://")) return true
        return normalized.startsWith("http://10.0.2.2") ||
            normalized.startsWith("http://localhost") ||
            normalized.startsWith("http://127.0.0.1")
    }

    var languageCode: String
        get() = prefs.getString(KEY_LANGUAGE_CODE, "hi-IN") ?: "hi-IN"
        set(value) = prefs.edit().putString(KEY_LANGUAGE_CODE, value).apply()

    var voiceName: String
        get() = prefs.getString(KEY_VOICE_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_VOICE_NAME, value).apply()

    var speechSpeed: Float
        get() = prefs.getFloat(KEY_SPEECH_SPEED, 1.05f).coerceIn(0.5f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_SPEED, value.coerceIn(0.5f, 2.0f)).apply()

    var speechPitch: Float
        get() = prefs.getFloat(KEY_SPEECH_PITCH, 1.25f).coerceIn(0.6f, 1.8f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_PITCH, value.coerceIn(0.6f, 1.8f)).apply()

    var eyeAnimationSpeed: Float
        get() = prefs.getFloat(KEY_EYE_ANIM_SPEED, 1.0f).coerceIn(0.4f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_EYE_ANIM_SPEED, value.coerceIn(0.4f, 2.0f)).apply()

    var cameraEnabled: Boolean
        get() = prefs.getBoolean(KEY_CAMERA_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CAMERA_ENABLED, value).apply()

    var mirrorCamera: Boolean
        get() = prefs.getBoolean(KEY_MIRROR_CAMERA, true)
        set(value) = prefs.edit().putBoolean(KEY_MIRROR_CAMERA, value).apply()

    var objectDetectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_OBJECT_DETECTION, true)
        set(value) = prefs.edit().putBoolean(KEY_OBJECT_DETECTION, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var saveHistoryEnabled: Boolean
        get() = prefs.getBoolean(KEY_SAVE_HISTORY, true)
        set(value) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, value).apply()

    companion object {
        private const val TAG = "SettingsManager"
        private const val PREFS_NAME = "looi_ai_settings"
        private const val SECURE_PREFS_NAME = "looi_ai_secrets"
        private const val KEY_AI_PROVIDER = "ai_provider"
        private const val KEY_GROQ_API_KEY = "groq_api_key"
        private const val KEY_GROQ_MODEL = "groq_model"
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_LANGUAGE_CODE = "language_code"
        private const val KEY_VOICE_NAME = "voice_name"
        private const val KEY_SPEECH_SPEED = "speech_speed"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_EYE_ANIM_SPEED = "eye_anim_speed"
        private const val KEY_CAMERA_ENABLED = "camera_enabled"
        private const val KEY_MIRROR_CAMERA = "mirror_camera"
        private const val KEY_OBJECT_DETECTION = "object_detection"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_SAVE_HISTORY = "save_history"

        const val PROVIDER_AUTO = "AUTO"
        const val PROVIDER_GROQ = "GROQ"
        const val PROVIDER_BACKEND = "BACKEND"

        private val RETIRED_GROQ_MODELS = setOf("mixtral-8x7b-32768", "gemma-7b-it", "llama3-70b-8192", "llama3-8b-8192")
        const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"
        const val DEFAULT_BACKEND_URL = "http://10.0.2.2:3000"
    }
}
