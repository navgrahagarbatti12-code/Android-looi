package com.looi.ai.ai.brain

import kotlin.math.max
import kotlin.math.min

data class RankableMemory(val id: Long, val content: String, val category: String, val updatedAt: Long)

data class RankedMemories(val instructions: List<String>, val facts: List<String>) {
    val isEmpty: Boolean get() = instructions.isEmpty() && facts.isEmpty()
}

/**
 * Chooses which saved memories go into the prompt so the model stays focused and token use stays low:
 * standing instructions always, then facts whose words overlap the user's message, then a few recent ones.
 */
object MemoryRanker {
    private const val DAY_MS = 86_400_000L

    private val stopWords = setOf(
        "the", "and", "for", "that", "this", "with", "you", "are", "was", "what", "when", "where", "have",
        "has", "had", "can", "could", "would", "should", "about", "your", "from", "they", "them", "its",
        "tell", "please", "kya", "hai", "hain", "nahi", "aur", "mera", "meri", "mere", "tum", "aap", "ko",
        "ka", "ki", "ke", "se", "par", "mein", "yeh", "woh", "ho", "hoon"
    )

    fun tokenize(text: String): Set<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
            .filter { it.isNotEmpty() && it !in stopWords && (it.length >= 3 || it.any { c -> c.code > 127 } && it.length >= 2) }
            .toSet()

    fun select(
        memories: List<RankableMemory>,
        query: String,
        now: Long,
        maxItems: Int = 8,
        maxChars: Int = 900
    ): RankedMemories {
        if (memories.isEmpty()) return RankedMemories(emptyList(), emptyList())

        val instructions = memories.filter { it.category == MemoryCategory.INSTRUCTION }
            .sortedByDescending { it.updatedAt }.take(5)
        val others = memories.filter { it.category != MemoryCategory.INSTRUCTION }

        val queryTokens = tokenize(query)
        val scored = others.map { m ->
            val overlap = tokenize(m.content).count { it in queryTokens }
            val ageDays = max(0L, now - m.updatedAt) / DAY_MS
            val recency = 1f - min(ageDays, 365L) / 365f
            Triple(m, overlap, overlap * 3f + recency)
        }
        val relevant = scored.filter { it.second > 0 }.sortedByDescending { it.third }.map { it.first }
        val filler = if (relevant.size < 3) {
            others.sortedByDescending { it.updatedAt }.filter { it !in relevant }.take(3 - relevant.size)
        } else emptyList()

        var used = instructions.sumOf { it.content.length }
        val facts = ArrayList<String>()
        for (m in relevant + filler) {
            if (facts.size + instructions.size >= maxItems) break
            if (used + m.content.length > maxChars) continue
            facts.add(m.content)
            used += m.content.length
        }
        return RankedMemories(instructions.map { it.content }, facts)
    }
}
