package com.looi.ai.ai.gemini

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.looi.ai.ai.HttpRetry
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Client for a SEPARATE, user-configured "Gemini companion backend" (not Google's API directly).
 * It posts to `<Backend URL>/api/looi/chat` and expects JSON `{ "reply": "..." }`.
 * The Gemini API secret stays on that server; nothing Gemini-related is stored in this app.
 * If no backend is running/configured, an explicit error is returned (no fake replies).
 */
class GeminiLiveClient(
    private val settingsManager: SettingsManager
) {
    private val tag = "GeminiBackendClient"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .build()

    suspend fun sendConversationTurn(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val baseUrl = settingsManager.backendUrl
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini backend URL set nahi hai. Settings me Backend URL ya Groq API Key daalein.")
            )
        }
        if (!settingsManager.isBackendUrlAllowedBySecurityPolicy(baseUrl)) {
            return@withContext Result.failure(
                IllegalStateException("Backend URL https:// hona chahiye (http sirf emulator/localhost ke liye).")
            )
        }
        if (!settingsManager.isOnline()) {
            return@withContext Result.failure(IOException("Internet connection nahi hai."))
        }

        try {
            val bodyString = JsonObject().apply {
                addProperty("message", userMessage)
                addProperty("language", settingsManager.languageCode)
                addProperty("detectedEmotion", detectedEmotion)
                addProperty("historyContext", historyContext)
                add("detectedObjects", gson.toJsonTree(detectedObjects))
            }.toString()

            val result = HttpRetry.execute(client) {
                Request.Builder()
                    .url("$baseUrl/api/looi/chat")
                    .post(bodyString.toRequestBody("application/json".toMediaType()))
                    .build()
            }

            if (result.code !in 200..299) {
                return@withContext Result.failure(
                    IOException("Gemini backend ($baseUrl) ne HTTP ${result.code} diya. Server check karein ya Groq use karein.")
                )
            }

            val reply = gson.fromJson(result.body, JsonObject::class.java)
                ?.get("reply")?.takeIf { it.isJsonPrimitive }?.asString
            if (reply.isNullOrBlank()) {
                Result.failure(IOException("Gemini backend ($baseUrl) ne khaali reply bheja."))
            } else {
                Result.success(reply)
            }
        } catch (e: com.google.gson.JsonParseException) {
            Result.failure(IOException("Gemini backend ka response JSON nahi hai.", e))
        } catch (e: IOException) {
            Log.e(tag, "Backend unreachable: ${e.javaClass.simpleName}")
            Result.failure(
                IOException("Gemini backend ($baseUrl) tak pahunch nahi paaye. Server chalu hai? Ya Groq API Key use karein.", e)
            )
        }
    }
}
