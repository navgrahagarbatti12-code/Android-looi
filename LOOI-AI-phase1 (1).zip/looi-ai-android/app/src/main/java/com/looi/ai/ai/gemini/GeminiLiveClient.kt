package com.looi.ai.ai.gemini

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Gemini Companion Backend Client.
 * Connects to the user-configured backend proxy endpoint /api/looi/chat,
 * keeping API secrets off the mobile client and reporting clear errors if unavailable.
 */
class GeminiLiveClient(
    private val settingsManager: SettingsManager
) {
    private val tag = "GeminiLiveClient"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun sendConversationTurn(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val baseUrl = settingsManager.backendUrl
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Backend URL is not configured. Add a Backend URL or Groq API Key in Settings.")
            )
        }

        try {
            val payload = JsonObject().apply {
                addProperty("message", userMessage)
                addProperty("language", settingsManager.languageCode)
                addProperty("detectedEmotion", detectedEmotion)
                addProperty("historyContext", historyContext)
                add("detectedObjects", gson.toJsonTree(detectedObjects))
            }

            val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$baseUrl/api/looi/chat")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = "Backend at $baseUrl returned HTTP ${response.code}. Check server logs or switch to Groq Direct API in Settings."
                    return@withContext Result.failure(IOException(detail))
                }

                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val replyText = json?.get("reply")?.asString
                if (replyText.isNullOrBlank()) {
                    return@withContext Result.failure(
                        IOException("Empty reply from backend at $baseUrl.")
                    )
                }
                Result.success(replyText)
            }
        } catch (e: ConnectException) {
            Log.e(tag, "Backend unreachable at $baseUrl", e)
            Result.failure(
                IOException("Cannot connect to Gemini backend at $baseUrl. Start the backend server or add a Groq API Key in Settings.", e)
            )
        } catch (e: UnknownHostException) {
            Log.e(tag, "Invalid backend host at $baseUrl", e)
            Result.failure(
                IOException("Invalid backend host ($baseUrl). Check Backend URL or switch to Groq Direct API in Settings.", e)
            )
        } catch (e: SocketTimeoutException) {
            Log.e(tag, "Backend timed out at $baseUrl", e)
            Result.failure(
                IOException("Gemini backend at $baseUrl timed out. Check your connection or try Groq Direct API in Settings.", e)
            )
        } catch (e: Exception) {
            Log.e(tag, "Companion backend communication error", e)
            Result.failure(
                IOException("Backend error (${e.localizedMessage ?: "Unknown"}). Check Settings.", e)
            )
        }
    }
}
