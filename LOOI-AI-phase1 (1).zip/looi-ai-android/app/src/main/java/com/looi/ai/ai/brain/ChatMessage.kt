package com.looi.ai.ai.brain

/** One OpenAI-style chat message. role is "system", "user" or "assistant". */
data class ChatMessage(val role: String, val content: String) {
    companion object {
        const val SYSTEM = "system"
        const val USER = "user"
        const val ASSISTANT = "assistant"
    }
}
