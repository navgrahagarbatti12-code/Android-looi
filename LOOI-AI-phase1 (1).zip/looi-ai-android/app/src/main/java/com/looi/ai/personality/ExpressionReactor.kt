package com.looi.ai.personality

import com.looi.ai.avatar.RobotEmotion

/**
 * Picks the face expression the robot shows the moment it hears the user, before the AI answers.
 * Keyword based (English, Hinglish, Hindi) so it works offline and instantly. The AI's own
 * [emotion:...] tag, when present, overrides this once the reply arrives.
 */
object ExpressionReactor {

    private val happy = listOf(
        "thank", "thanks", "love", "great", "awesome", "nice", "good morning", "congrat", "haha", "lol",
        "shukriya", "dhanyavad", "badhai", "mast", "badhiya", "accha hai", "शुक्रिया", "धन्यवाद", "बधाई"
    )
    private val sad = listOf(
        "sad", "cry", "lonely", "miss ", "tired", "depressed", "bad day", "hurt",
        "dukhi", "udaas", "rona", "akela", "thaka", "dard", "दुखी", "उदास", "अकेला", "थक"
    )
    private val angry = listOf(
        "angry", "hate", "annoying", "stupid", "shut up", "furious",
        "gussa", "bakwas", "chup", "गुस्सा", "बकवास"
    )
    private val surprised = listOf(
        "wow", "omg", "no way", "really?", "unbelievable", "amazing",
        "sach me", "sach mein", "kya baat", "arey wah", "अरे वाह", "सच में"
    )
    private val questionWords = listOf(
        "why", "how", "what", "who", "when", "where", "kyun", "kyu", "kaise", "kya", "kaun", "kab", "kahan",
        "क्यों", "कैसे", "क्या", "कौन", "कब", "कहाँ"
    )

    fun reactionFor(text: String, personality: RobotPersonality): RobotEmotion? {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return null
        return when {
            sad.any { t.contains(it) } -> RobotEmotion.SAD
            angry.any { t.contains(it) } ->
                // Emotional robots soften instead of mirroring anger.
                if (personality == RobotPersonality.EMOTIONAL) RobotEmotion.SAD else RobotEmotion.ANGRY
            surprised.any { t.contains(it) } -> RobotEmotion.SURPRISED
            happy.any { t.contains(it) } -> RobotEmotion.HAPPY
            t.endsWith("?") || startsWithWord(t, questionWords) ->
                if (personality == RobotPersonality.CURIOUS || personality == RobotPersonality.INTELLIGENT)
                    RobotEmotion.CURIOUS else null
            else -> null
        }
    }

    private fun startsWithWord(text: String, words: List<String>): Boolean =
        words.any { text == it || text.startsWith("$it ") }
}
