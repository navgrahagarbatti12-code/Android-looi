package com.looi.ai.ai.brain

import com.looi.ai.avatar.RobotEmotion

/** A model reply after control tags have been removed. */
data class ParsedReply(
    val text: String,
    val emotion: RobotEmotion?,
    /** A fact the AI suggests saving. It is only ever saved after the user approves it. */
    val memoryProposal: String?
)

/**
 * The system prompt asks the model to end replies with `[emotion:happy]` and, rarely,
 * `[remember: ...]`. This strips both so they are never shown or spoken.
 */
object ReplyParser {
    private val emotionTag = Regex("\\[\\s*(?:emotion|mood)\\s*[:=]\\s*([A-Za-z]+)\\s*]")
    private val rememberTag = Regex("\\[\\s*remember\\s*[:=]\\s*([^\\]]{3,200})]", RegexOption.IGNORE_CASE)
    private val danglingTag = Regex("\\[[^\\]]*$")
    private val multiSpace = Regex("[ \\t]{2,}")

    private val emotionMap = mapOf(
        "happy" to RobotEmotion.HAPPY, "joy" to RobotEmotion.HAPPY, "excited" to RobotEmotion.HAPPY,
        "sad" to RobotEmotion.SAD, "empathy" to RobotEmotion.SAD,
        "angry" to RobotEmotion.ANGRY, "annoyed" to RobotEmotion.ANGRY,
        "surprised" to RobotEmotion.SURPRISED, "surprise" to RobotEmotion.SURPRISED,
        "curious" to RobotEmotion.CURIOUS, "thinking" to RobotEmotion.CURIOUS
    )

    fun parse(raw: String): ParsedReply {
        var emotion: RobotEmotion? = null
        emotionTag.findAll(raw).forEach { m ->
            emotionMap[m.groupValues[1].lowercase()]?.let { emotion = it }
        }
        val proposal = rememberTag.find(raw)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotEmpty() && !SensitiveDataFilter.isSensitive(it) }

        val cleaned = raw
            .replace(emotionTag, "")
            .replace(rememberTag, "")
            .replace(danglingTag, "")
            .replace(multiSpace, " ")
            .trim()
        return ParsedReply(cleaned, emotion, proposal)
    }
}
