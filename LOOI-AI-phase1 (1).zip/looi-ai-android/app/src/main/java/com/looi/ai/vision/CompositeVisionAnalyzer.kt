package com.looi.ai.vision

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.utils.SmoothingFilter
import kotlin.math.abs

/**
 * Combined non-blocking CameraX ImageAnalysis.Analyzer that runs
 * ML Kit Face Tracking (every frame) and ML Kit Object Detection (every 3rd frame)
 * on a background executor, closing ImageProxy only after both tasks complete.
 */
class CompositeVisionAnalyzer(
    private val faceListener: FaceTrackingListener,
    private val objectListener: ObjectDetectionListener,
    @Volatile var isObjectDetectionEnabled: Boolean = true,
    @Volatile var isFrontCameraMirrored: Boolean = true
) : ImageAnalysis.Analyzer {

    @Volatile
    private var isClosed = false

    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setMinFaceSize(0.15f)
            .build()
    )

    private val objectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .enableMultipleObjects()
            .build()
    )

    private val smoothX = SmoothingFilter(0.32f)
    private val smoothY = SmoothingFilter(0.32f)

    private var consecutiveLostFrames = 0
    private val lostThreshold = 8
    private var frameCounter = 0

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        if (isClosed) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        // ML Kit returns bounding boxes in upright (post-rotation) coordinates
        val uprightWidth = if (rotation == 90 || rotation == 270) {
            mediaImage.height.toFloat()
        } else {
            mediaImage.width.toFloat()
        }
        val uprightHeight = if (rotation == 90 || rotation == 270) {
            mediaImage.width.toFloat()
        } else {
            mediaImage.height.toFloat()
        }

        val tasks = mutableListOf<Task<*>>()

        // 1. Face Tracking Task (every frame)
        val faceTask = faceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                handleFaces(faces, uprightWidth, uprightHeight)
            }
            .addOnFailureListener {
                consecutiveLostFrames++
                if (consecutiveLostFrames >= lostThreshold) {
                    faceListener.onFaceLost()
                }
            }
        tasks.add(faceTask)

        // 2. Object Detection Task (every 3rd frame to save battery & CPU)
        frameCounter++
        if (isObjectDetectionEnabled && frameCounter % 3 == 0) {
            val objectTask = objectDetector.process(inputImage)
                .addOnSuccessListener { detectedObjects ->
                    handleObjects(detectedObjects, facesDetected = false)
                }
            tasks.add(objectTask)
        }

        Tasks.whenAllComplete(tasks)
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun handleFaces(faces: List<Face>, frameWidth: Float, frameHeight: Float) {
        if (faces.isNotEmpty() && frameWidth > 0f && frameHeight > 0f) {
            consecutiveLostFrames = 0
            val face = faces[0]
            val box = face.boundingBox

            val mirrorSign = if (isFrontCameraMirrored) -1f else 1f
            val rawCenterX = ((box.centerX() / frameWidth) - 0.5f) * 2f * mirrorSign
            val rawCenterY = ((box.centerY() / frameHeight) - 0.5f) * 2f

            val filteredX = smoothX.filter(rawCenterX.coerceIn(-1f, 1f))
            val filteredY = smoothY.filter(rawCenterY.coerceIn(-1f, 1f))

            val smileProb = face.smilingProbability ?: 0f
            val leftEyeOpen = face.leftEyeOpenProbability ?: 1f
            val rightEyeOpen = face.rightEyeOpenProbability ?: 1f
            val headEulerZ = face.headEulerAngleZ

            val emotion = when {
                smileProb > 0.65f -> RobotEmotion.HAPPY
                leftEyeOpen < 0.2f && rightEyeOpen < 0.2f -> RobotEmotion.SLEEPING
                leftEyeOpen < 0.35f || rightEyeOpen < 0.35f -> RobotEmotion.CURIOUS
                abs(headEulerZ) > 18f -> RobotEmotion.CURIOUS
                else -> RobotEmotion.HAPPY
            }

            faceListener.onFaceTracked(filteredX, filteredY, emotion, face)
        } else {
            consecutiveLostFrames++
            if (consecutiveLostFrames >= lostThreshold) {
                faceListener.onFaceLost()
            }
        }
    }

    private fun handleObjects(detectedObjects: List<DetectedObject>, facesDetected: Boolean) {
        val labels = mutableListOf<String>()
        var dominantLabel: String? = null
        var maxConfidence = 0.45f

        for (obj in detectedObjects) {
            val bestLabel = obj.labels.maxByOrNull { it.confidence }
            if (bestLabel != null && bestLabel.confidence > 0.45f) {
                labels.add(bestLabel.text)
                if (bestLabel.confidence > maxConfidence) {
                    maxConfidence = bestLabel.confidence
                    dominantLabel = bestLabel.text
                }
            }
        }

        if (dominantLabel == null && detectedObjects.isNotEmpty()) {
            dominantLabel = if (facesDetected) "Person" else "Object"
        }

        objectListener.onObjectsDetected(detectedObjects, dominantLabel)
    }

    fun close() {
        isClosed = true
        try {
            faceDetector.close()
            objectDetector.close()
        } catch (_: Exception) {
        }
    }
}
