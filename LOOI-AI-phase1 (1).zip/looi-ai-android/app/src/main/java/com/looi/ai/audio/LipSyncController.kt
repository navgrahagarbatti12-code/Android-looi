package com.looi.ai.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.util.Log
import androidx.core.content.ContextCompat
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.avatar.RobotFaceCanvasView
import com.looi.ai.utils.SmoothingFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Connects real-time speech audio amplitude to the RobotFaceCanvasView mouth aperture.
 * Uses Android's Visualizer API bound to the TTS AudioSessionId when supported and permitted,
 * and falls back to a clearly identified smooth syllable-cadence animation if Visualizer
 * is unavailable on the device.
 */
class LipSyncController(
    private val context: Context,
    private val robotFaceView: RobotFaceCanvasView,
    private val scope: CoroutineScope
) {
    private val tag = "LipSyncController"
    private val amplitudeFilter = SmoothingFilter(0.42f)

    private var visualizer: Visualizer? = null
    private var fallbackJob: Job? = null

    /** Timestamp of the last Visualizer frame with a real signal (0 = none yet). */
    @Volatile
    private var lastRealSignalMs = 0L

    var isUsingRealAudioSync: Boolean = false
        private set

    fun onSpeakingStarted(audioSessionId: Int = 0) {
        robotFaceView.currentEmotion = RobotEmotion.TALKING
        stopSyncInternal()

        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        lastRealSignalMs = 0L
        isUsingRealAudioSync = hasPermission && audioSessionId > 0 && startVisualizerSync(audioSessionId)
        Log.d(tag, "Lip-sync: visualizer attached=$isUsingRealAudioSync")
        // The cadence animation always runs but only drives the mouth while no real audio
        // signal is arriving (Visualizer unsupported, or silent frames on some TTS engines).
        startFallbackCadenceAnimation()
    }

    private fun startVisualizerSync(audioSessionId: Int): Boolean {
        return try {
            val captureSize = Visualizer.getCaptureSizeRange()[0]
            val viz = Visualizer(audioSessionId).apply {
                this.captureSize = captureSize
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(
                            visualizer: Visualizer?,
                            waveform: ByteArray?,
                            samplingRate: Int
                        ) {
                            if (waveform == null || waveform.isEmpty()) return
                            var sumSq = 0.0
                            for (b in waveform) {
                                // Unsigned PCM 8-bit centered at 128
                                val centered = (b.toInt() and 0xFF) - 128
                                sumSq += centered * centered
                            }
                            val rms = sqrt(sumSq / waveform.size).toFloat() / 128f
                            val level = (rms * 2.6f).coerceIn(0f, 1f)
                            if (level > REAL_SIGNAL_THRESHOLD) {
                                lastRealSignalMs = android.os.SystemClock.elapsedRealtime()
                            }
                            if (android.os.SystemClock.elapsedRealtime() - lastRealSignalMs < REAL_SIGNAL_HOLD_MS) {
                                onAudioFrameAmplitude(level)
                            }
                        }

                        override fun onFftDataCapture(
                            visualizer: Visualizer?,
                            fft: ByteArray?,
                            samplingRate: Int
                        ) {
                            // Not needed for mouth aperture
                        }
                    },
                    Visualizer.getMaxCaptureRate() / 2,
                    true,
                    false
                )
                enabled = true
            }
            visualizer = viz
            true
        } catch (e: Exception) {
            Log.w(tag, "Visualizer unavailable for TTS session ($audioSessionId), using fallback cadence: ${e.message}")
            releaseVisualizer()
            false
        }
    }

    /**
     * Clearly identified fallback mouth cadence animation used only when
     * Android's audio Visualizer cannot bind to the TTS output session.
     */
    private fun startFallbackCadenceAnimation() {
        fallbackJob = scope.launch {
            var phase = 0f
            while (isActive) {
                val realActive = lastRealSignalMs != 0L &&
                    android.os.SystemClock.elapsedRealtime() - lastRealSignalMs < REAL_SIGNAL_HOLD_MS
                if (!realActive) {
                    val cadence = (abs(sin(phase)) * 0.65f + abs(sin(phase * 2.3f)) * 0.35f)
                        .coerceIn(0.08f, 0.9f)
                    onAudioFrameAmplitude(cadence)
                }
                phase += 0.45f
                delay(45L)
            }
        }
    }

    fun onAudioFrameAmplitude(rawRms: Float) {
        val smoothed = synchronized(amplitudeFilter) {
            amplitudeFilter.filter(rawRms.coerceIn(0f, 1f))
        }
        robotFaceView.mouthAmplitude = smoothed
    }

    fun onSpeakingFinished(restoringEmotion: RobotEmotion = RobotEmotion.HAPPY) {
        stopSyncInternal()
        synchronized(amplitudeFilter) {
            amplitudeFilter.reset()
        }
        robotFaceView.mouthAmplitude = 0f
        robotFaceView.currentEmotion = restoringEmotion
    }

    private fun stopSyncInternal() {
        fallbackJob?.cancel()
        fallbackJob = null
        releaseVisualizer()
    }

    private fun releaseVisualizer() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (_: Exception) {
        } finally {
            visualizer = null
        }
    }

    fun release() {
        stopSyncInternal()
    }

    private companion object {
        const val REAL_SIGNAL_THRESHOLD = 0.04f
        const val REAL_SIGNAL_HOLD_MS = 250L
    }
}
