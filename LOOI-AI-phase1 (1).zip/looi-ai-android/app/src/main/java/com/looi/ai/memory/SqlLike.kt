package com.looi.ai.memory

/** Escapes LIKE wildcards so user text is matched literally (pair with `ESCAPE '\'` in the query). */
object SqlLike {
    fun escape(raw: String): String =
        raw.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
