package com.looi.ai.memory.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "USER" or "LOOI"
    val messageText: String,
    val detectedEmotion: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
