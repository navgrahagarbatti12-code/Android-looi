package com.looi.ai.ai.brain

/**
 * Privacy guard: text that looks like a secret must never be written to long-term memory,
 * whether the user asked for it or the AI proposed it.
 */
object SensitiveDataFilter {
    private val keywords = listOf(
        "password", "passcode", "passwd", "otp", "cvv", "pin is", "pin number", "my pin", "card number",
        "credit card", "debit card", "aadhaar", "aadhar", "pan number", "ssn", "social security",
        "api key", "secret key", "private key", "bank account", "account number", "upi pin",
        "पासवर्ड", "ओटीपी", "आधार"
    )
    // 13-19 digit runs (cards, possibly spaced/dashed) and 12-digit Aadhaar-like numbers.
    private val longDigits = Regex("(?:\\d[ -]?){12,19}")

    fun isSensitive(text: String): Boolean {
        val t = text.lowercase()
        if (keywords.any { t.contains(it) }) return true
        return longDigits.containsMatchIn(t)
    }
}
