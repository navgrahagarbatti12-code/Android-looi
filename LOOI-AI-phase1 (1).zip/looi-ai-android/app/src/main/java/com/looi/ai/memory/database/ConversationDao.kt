package com.looi.ai.memory.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Query("SELECT * FROM conversations ORDER BY timestamp ASC, id ASC")
    fun getAllMessages(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun getRecentContext(limit: Int): List<ConversationEntity>

    @Query("SELECT * FROM conversations ORDER BY timestamp DESC, id DESC LIMIT 1")
    suspend fun getLastMessage(): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(message: ConversationEntity): Long

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteById(id: Long): Int

    @Query("DELETE FROM conversations")
    suspend fun clearAll()

    @Query("SELECT * FROM conversations WHERE messageText LIKE '%' || :escaped || '%' ESCAPE '\\' ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun search(escaped: String, limit: Int): List<ConversationEntity>

    /** Matches older than [before] only, so recalled lines never duplicate the recent chat window. */
    @Query("SELECT * FROM conversations WHERE timestamp < :before AND messageText LIKE '%' || :escaped || '%' ESCAPE '\\' ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun searchBefore(escaped: String, before: Long, limit: Int): List<ConversationEntity>

    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getCount(): Int
}
