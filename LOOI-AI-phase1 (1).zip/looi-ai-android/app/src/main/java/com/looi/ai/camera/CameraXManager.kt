package com.looi.ai.camera

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Production-ready CameraX Manager for LOOI AI.
 * Handles front-facing camera binding, PreviewView rendering,
 * session-token race-condition prevention, lifecycle safety, and background frame analysis.
 */
class CameraXManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView
) {
    private val tag = "CameraXManager"
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalyzer: ImageAnalysis? = null

    @Volatile
    private var isRunning = false
    @Volatile
    private var isStarting = false
    private val sessionToken = AtomicInteger(0)

    fun startCamera(analyzer: ImageAnalysis.Analyzer, onError: (Exception) -> Unit) {
        if (isRunning || isStarting) {
            Log.d(tag, "CameraX already running or starting; skipping duplicate bind.")
            return
        }
        if (lifecycleOwner.lifecycle.currentState == Lifecycle.State.DESTROYED) {
            return
        }

        val activeToken = sessionToken.incrementAndGet()
        isStarting = true
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            isStarting = false
            // Abort if stopCamera() or another startCamera() superseded this async callback
            if (activeToken != sessionToken.get() ||
                lifecycleOwner.lifecycle.currentState == Lifecycle.State.DESTROYED
            ) {
                Log.d(tag, "CameraX async start cancelled because session changed or lifecycle destroyed.")
                return@addListener
            }

            try {
                if (cameraExecutor.isShutdown) {
                    cameraExecutor = Executors.newSingleThreadExecutor()
                }

                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val preview = Preview.Builder()
                    .build()
                    .also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                imageAnalyzer = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, analyzer)
                    }

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageAnalyzer
                )

                isRunning = true
                Log.d(tag, "CameraX front camera successfully started.")
            } catch (exc: Exception) {
                isRunning = false
                Log.e(tag, "Camera initialization failed", exc)
                onError(exc)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stopCamera() {
        // Invalidate any in-flight startCamera() listener
        sessionToken.incrementAndGet()
        isStarting = false
        isRunning = false
        ContextCompat.getMainExecutor(context).execute {
            try {
                imageAnalyzer?.clearAnalyzer()
                imageAnalyzer = null
                cameraProvider?.unbindAll()
                Log.d(tag, "CameraX stopped safely.")
            } catch (e: Exception) {
                Log.w(tag, "Error stopping CameraX: ${e.message}")
            }
        }
    }

    fun release() {
        stopCamera()
        if (!cameraExecutor.isShutdown) {
            cameraExecutor.shutdown()
        }
    }

    fun isCameraRunning(): Boolean = isRunning
}
