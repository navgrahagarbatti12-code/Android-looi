package com.looi.ai.ai.brain

/** What the user asked for when the sentence is a memory command rather than normal chat. */
sealed class MemoryIntent {
    data class Remember(val text: String) : MemoryIntent()
    data class Forget(val text: String) : MemoryIntent()
    object ListMemories : MemoryIntent()
    data class SearchConversations(val query: String) : MemoryIntent()
    object None : MemoryIntent()
}

object MemoryCategory {
    const val FACT = "FACT"
    const val PREFERENCE = "PREFERENCE"
    const val INSTRUCTION = "INSTRUCTION"

    private val instructionStarts = listOf(
        "always ", "never ", "whenever ", "from now on", "don't ", "do not ", "please always",
        "hamesha ", "kabhi mat", "ab se", "आगे से", "हमेशा"
    )
    private val preferenceHints = listOf(
        "i like", "i love", "i prefer", "i hate", "i dislike", "my favourite", "my favorite",
        "mujhe pasand", "mujhe achha lagta", "mera favourite", "mera favorite", "मुझे पसंद"
    )

    fun categorize(text: String): String {
        val t = text.lowercase().trim()
        return when {
            instructionStarts.any { t.startsWith(it) } -> INSTRUCTION
            preferenceHints.any { t.contains(it) } -> PREFERENCE
            else -> FACT
        }
    }
}

/** Recognises "remember …", "forget …", "what do you remember?" and "search conversations for …". */
object MemoryIntentParser {
    private val opt = RegexOption.IGNORE_CASE
    private const val LEAD = "^(?:hey\\s+looi[,!]?\\s*|ok(?:ay)?\\s+looi[,!]?\\s*|looi[,!]?\\s*|please\\s+)*"

    private val forget = Regex(
        LEAD + "(?:forget|bhool\\s*ja(?:o|na)?|भूल\\s*जाओ)\\s*(?:about|that|ki|कि)?\\s+(.+)$", opt
    )
    private val remember = Regex(
        LEAD + "(?:remember|yaad\\s*rakh(?:o|na)?|याद\\s*रख(?:ो|ना)?)\\s*(?:that|ki|कि)?\\s+(.+)$", opt
    )
    private val list = listOf(
        Regex("what\\s+do\\s+you\\s+(?:remember|know)(?:\\s+about\\s+me)?\\s*[?.!]*$", opt),
        Regex("show\\s+(?:me\\s+)?(?:my\\s+)?memor(?:y|ies)\\s*[?.!]*$", opt),
        Regex("tumhe\\s+(?:mere\\s+baare\\s+mein\\s+)?kya\\s+yaad\\s+hai\\s*[?.!]*$", opt),
        Regex("mere\\s+baare\\s+mein\\s+kya\\s+(?:jaante|pata)\\s+ho\\s*[?.!]*$", opt),
        Regex("तुम्हें\\s+क्या\\s+याद\\s+है\\s*[?.!]*$", opt)
    )
    private val search = listOf(
        Regex("(?:search|find|look\\s+up)\\s+(?:my\\s+|our\\s+|old\\s+|past\\s+|previous\\s+)*(?:conversations?|chats?|messages?)\\s+(?:for|about)\\s+(.+)$", opt),
        Regex("what\\s+did\\s+(?:i|we)\\s+(?:say|said|talk(?:ed)?|tell|told|discuss(?:ed)?)\\w*\\s+about\\s+(.+)$", opt),
        Regex("(.+?)\\s+ke\\s+baare\\s+mein\\s+(?:humne|maine|pehle)\\s+kya\\s+(?:baat|kaha).*$", opt)
    )

    fun parse(input: String): MemoryIntent {
        val text = input.trim()
        if (text.isEmpty()) return MemoryIntent.None

        forget.find(text)?.let { clean(it.groupValues[1])?.let { c -> return MemoryIntent.Forget(c) } }
        remember.find(text)?.let { clean(it.groupValues[1])?.let { c -> return MemoryIntent.Remember(c) } }
        if (list.any { it.containsMatchIn(text) }) return MemoryIntent.ListMemories
        for (r in search) {
            r.find(text)?.let { clean(it.groupValues[1])?.let { c -> return MemoryIntent.SearchConversations(c) } }
        }
        return MemoryIntent.None
    }

    private fun clean(s: String): String? =
        s.trim().trim('.', '!', '?', '"', '\'', ' ').takeIf { it.length >= 2 }
}
