package com.looi.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.objects.DetectedObject
import com.looi.ai.LooiApplication
import com.looi.ai.R
import com.looi.ai.ai.AiRouter
import com.looi.ai.ai.brain.BrainController
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.audio.LipSyncController
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.camera.CameraXManager
import com.looi.ai.databinding.ActivityMainBinding
import com.looi.ai.memory.MemorySaveResult
import com.looi.ai.personality.ExpressionReactor
import com.looi.ai.personality.RobotPersonality
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.CompositeVisionAnalyzer
import com.looi.ai.vision.FaceTrackingListener
import com.looi.ai.vision.ObjectDetectionListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Main LOOI AI Companion Activity.
 * Integrates CameraX front camera, simultaneous ML Kit Face & Object Tracking,
 * configurable Groq/Gemini AI conversation, Speech-to-Text, Text-to-Speech,
 * Room persistent memory, and real-time lip-sync.
 */
class MainActivity : AppCompatActivity(), FaceTrackingListener, ObjectDetectionListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private lateinit var lipSyncController: LipSyncController
    private lateinit var groqManager: GroqManager
    private lateinit var aiRouter: AiRouter
    private lateinit var brain: BrainController
    private var personality = RobotPersonality.DEFAULT
    private var memoryDialog: AlertDialog? = null

    private var cameraXManager: CameraXManager? = null
    private var visionAnalyzer: CompositeVisionAnalyzer? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isListening = false
    private var isProcessing = false
    private var speechRetryCount = 0
    private var ttsAudioSessionId = 0

    private var currentEmotion = RobotEmotion.HAPPY
    private val detectedObjectsList = mutableListOf<String>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.containsKey(Manifest.permission.CAMERA)) {
            val cameraGranted = permissions[Manifest.permission.CAMERA] == true
            if (cameraGranted && settings.cameraEnabled) {
                setupCamera()
            } else if (!cameraGranted) {
                cameraXManager?.stopCamera()
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAMERA DENIED"
                settings.cameraEnabled = false
                offerAppSettingsIfPermanentlyDenied(
                    Manifest.permission.CAMERA,
                    "Camera permission denied. Face & object tracking band hai."
                )
            }
        }

        if (permissions.containsKey(Manifest.permission.RECORD_AUDIO)) {
            val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
            if (audioGranted) {
                initSpeechRecognizer()
            } else {
                offerAppSettingsIfPermanentlyDenied(
                    Manifest.permission.RECORD_AUDIO,
                    "Microphone permission denied. Voice input ke liye mic access chahiye."
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager
        groqManager = GroqManager(settings)
        aiRouter = AiRouter(settings, groqManager, GeminiLiveClient(settings))
        brain = BrainController(settings, aiRouter, LooiApplication.instance.memoryRepository)
        lipSyncController = LipSyncController(this, binding.robotFaceView, lifecycleScope)

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        ttsAudioSessionId = audioManager?.generateAudioSessionId() ?: 0

        initTextToSpeech()
        setupButtons()
        applySettingsToRuntime()
        checkPermissionsAndStart()

        // First launch: ask for the API key right inside the app
        if (settings.groqApiKey.isBlank() && savedInstanceState == null) {
            binding.root.post { showApiKeyDialog() }
        }
    }

    /** Lets the user paste / change the Groq API key without opening Settings. */
    private fun showApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "gsk_..."
            setText(settings.groqApiKey)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSelection(text.length)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val container = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Groq API Key")
            .setMessage("console.groq.com se free key lekar yahan paste karein.")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isNotEmpty() && !settings.isGroqKeyFormatValid(key)) {
                    Toast.makeText(this, "Key galat format me hai (Groq key 'gsk_' se shuru hoti hai).", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                settings.groqApiKey = key
                if (key.isNotEmpty()) settings.aiProvider = SettingsManager.PROVIDER_GROQ
                val msg = when {
                    key.isEmpty() -> "API key removed"
                    !settings.isSecureStorageAvailable -> "Key sirf is session ke liye save hui (secure storage unavailable)."
                    else -> "API key saved!"
                }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Later", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToRuntime()
        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            cameraXManager?.isCameraRunning() != true
        ) {
            setupCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        if (isListening) {
            stopVoiceListening()
        }
        textToSpeech?.stop()
        lipSyncController.onSpeakingFinished(currentEmotion)
    }

    private fun applySettingsToRuntime() {
        binding.robotFaceView.animationSpeedMultiplier = settings.eyeAnimationSpeed

        val selected = RobotPersonality.fromId(settings.personalityId)
        if (selected != personality) {
            personality = selected
            currentEmotion = selected.idleEmotion
            if (!isProcessing && !isListening) binding.robotFaceView.currentEmotion = currentEmotion
        }

        visionAnalyzer?.isObjectDetectionEnabled = settings.objectDetectionEnabled
        visionAnalyzer?.isFrontCameraMirrored = settings.mirrorCamera

        if (!settings.objectDetectionEnabled) {
            binding.tvDetectedObjects.visibility = View.GONE
        }

        if (!settings.cameraEnabled) {
            cameraXManager?.stopCamera()
            binding.cameraPreviewCard.visibility = View.GONE
            binding.tvDetectedObjects.visibility = View.GONE
        } else if (binding.cameraPreviewCard.visibility != View.VISIBLE &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) {
            binding.cameraPreviewCard.visibility = View.VISIBLE
        }

        if (isTtsReady) {
            applyTtsSettings()
        }
    }

    private fun checkPermissionsAndStart() {
        val permissionsToRequest = mutableListOf<String>()
        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            if (settings.cameraEnabled) {
                setupCamera()
            }
            initSpeechRecognizer()
        }
    }

    private fun setupCamera() {
        if (!settings.cameraEnabled) return
        if (cameraXManager == null) {
            cameraXManager = CameraXManager(this, this, binding.cameraPreviewView)
        }
        if (visionAnalyzer == null) {
            visionAnalyzer = CompositeVisionAnalyzer(
                faceListener = this,
                objectListener = this,
                isObjectDetectionEnabled = settings.objectDetectionEnabled,
                isFrontCameraMirrored = settings.mirrorCamera
            )
        }

        val analyzer = visionAnalyzer ?: return
        binding.cameraPreviewCard.visibility = View.VISIBLE
        cameraXManager?.startCamera(analyzer) { error ->
            runOnUiThread {
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAM ERROR"
                Toast.makeText(
                    this,
                    "Camera unavailable: ${error.localizedMessage ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                applyTtsSettings()

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingStarted(ttsAudioSessionId)
                            binding.tvEmotionStatus.text = "STATE: SPEAKING"
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingFinished(currentEmotion)
                            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingFinished(currentEmotion)
                            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        onError(utteranceId)
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        runOnUiThread {
                            lipSyncController.onSpeakingFinished(currentEmotion)
                            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                        }
                    }
                })
            } else {
                isTtsReady = false
                Toast.makeText(
                    this,
                    "Text-to-Speech engine start nahi hua. Subtitles chalte rahenge, awaaz nahi aayegi.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun applyTtsSettings() {
        val tts = textToSpeech ?: return
        val locale = Locale.forLanguageTag(settings.languageCode)
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "IN"))
        }

        val preferredVoice = settings.voiceName
        if (preferredVoice.isNotBlank()) {
            val matched = tts.voices?.firstOrNull { it.name == preferredVoice }
            if (matched != null) {
                tts.voice = matched
            }
        }

        // Personality colours the voice on top of the user's own pitch/speed settings
        tts.setPitch((settings.speechPitch * personality.pitchFactor).coerceIn(0.5f, 2.0f))
        tts.setSpeechRate((settings.speechSpeed * personality.speedFactor).coerceIn(0.4f, 2.5f))
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    updateMicIndicator(true)
                    binding.tvSubtitleSpeaker.text = "LOOI AI (Listening…)"
                    binding.tvEmotionStatus.text = "STATE: LISTENING"
                    binding.robotFaceView.currentEmotion = RobotEmotion.LISTENING
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = (rmsdB / 10f).coerceIn(0f, 1f)
                    binding.robotFaceView.mouthAmplitude = normalized * 0.4f
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isListening = false
                    updateMicIndicator(false)
                    binding.robotFaceView.mouthAmplitude = 0f
                    binding.tvEmotionStatus.text = "STATE: THINKING"
                    binding.robotFaceView.currentEmotion = RobotEmotion.THINKING
                }

                override fun onError(error: Int) {
                    isListening = false
                    updateMicIndicator(false)
                    // One automatic retry for transient recognizer failures
                    if ((error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) &&
                        speechRetryCount < 1
                    ) {
                        speechRetryCount++
                        binding.root.postDelayed({
                            initSpeechRecognizer()
                            startVoiceListening()
                        }, 400)
                        return
                    }
                    binding.robotFaceView.mouthAmplitude = 0f
                    binding.robotFaceView.currentEmotion = currentEmotion
                    binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        binding.tvSubtitleSpeaker.text = "LOOI AI"
                        binding.tvSubtitleText.text = when (error) {
                            SpeechRecognizer.ERROR_NETWORK,
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Internet nahi mil raha, voice recognition ke liye network chahiye."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission chahiye. Android Settings me allow karein."
                            else -> "Mic error ($error). Tap mic to try again."
                        }
                        // BUSY / CLIENT / unknown errors leave the recognizer unusable: rebuild it
                        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_CLIENT ||
                            error == SpeechRecognizer.ERROR_SERVER
                        ) {
                            binding.root.post { initSpeechRecognizer() }
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    speechRetryCount = 0
                    updateMicIndicator(false)
                    binding.robotFaceView.mouthAmplitude = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull().orEmpty()
                    if (spokenText.isNotBlank()) {
                        processUserQuery(spokenText)
                    } else {
                        binding.robotFaceView.currentEmotion = currentEmotion
                        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        binding.tvSubtitleText.text = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun offerAppSettingsIfPermanentlyDenied(permission: String, message: String) {
        if (shouldShowRequestPermissionRationale(permission)) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Permission chahiye")
            .setMessage("$message\nAndroid Settings me jaakar allow karein.")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(
                    Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.fromParts("package", packageName, null)
                    )
                )
            }
            .setNegativeButton("Not now", null)
            .show()
    }

    /** Visible mic status: red + "STATE: LISTENING" while the microphone is open, cyan otherwise. */
    private fun updateMicIndicator(active: Boolean) {
        val color = if (active) R.color.looi_red else R.color.looi_cyan
        binding.btnMic.backgroundTintList =
            android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, color))
        binding.btnMic.contentDescription = if (active) "Stop listening" else "Start voice listening"
    }

    private fun setThinking(active: Boolean) {
        isProcessing = active
        binding.progressThinking.visibility = if (active) View.VISIBLE else View.GONE
    }

    private fun processUserQuery(query: String) {
        if (isProcessing) return // prevents duplicate AI calls / duplicate replies
        setThinking(true)
        lifecycleScope.launch {
          try {
            binding.tvSubtitleSpeaker.text = "You said:"
            binding.tvSubtitleText.text = query

            // Instant, personality-aware reaction to what the user said
            val reaction = ExpressionReactor.reactionFor(query, personality)
            val pending = async {
                try {
                    brain.respond(
                        userText = query,
                        userEmotion = currentEmotion.name,
                        visibleObjects = detectedObjectsList.toList()
                    )
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // e.g. a database error: show it as a normal failure instead of crashing
                    Result.failure(e)
                }
            }
            if (reaction != null) {
                binding.robotFaceView.currentEmotion = reaction
                delay(REACTION_MS)
            }
            if (pending.isActive) {
                binding.tvEmotionStatus.text = "STATE: THINKING"
                binding.robotFaceView.currentEmotion = RobotEmotion.THINKING
            }

            pending.await().onSuccess { reply ->
                // AI's own expression tag wins, then the instant reaction, then the personality's idle face
                val replyEmotion = reply.emotion ?: reaction ?: personality.idleEmotion
                currentEmotion = replyEmotion
                binding.robotFaceView.currentEmotion = replyEmotion
                binding.tvSubtitleSpeaker.text = "LOOI AI:"
                binding.tvSubtitleText.text = reply.text
                speakLooi(reply.text)
                reply.memoryProposal?.let { askToSaveMemory(it) }
            }.onFailure { err ->
                currentEmotion = RobotEmotion.SAD
                binding.robotFaceView.currentEmotion = RobotEmotion.SAD
                binding.tvEmotionStatus.text = "NETWORK / API ERROR"
                binding.tvSubtitleSpeaker.text = "LOOI AI (Setup Needed):"
                binding.tvSubtitleText.text = err.localizedMessage
                    ?: "Network error. Check Settings for Groq API Key or Backend URL."
                if (settings.aiProvider != SettingsManager.PROVIDER_BACKEND &&
                    (settings.groqApiKey.isBlank() || err.localizedMessage?.contains("API key", true) == true)
                ) {
                    showApiKeyDialog()
                }
            }
          } finally {
            setThinking(false)
          }
        }
    }

    /** The AI suggested remembering something. Nothing is saved unless the user taps Save. */
    private fun askToSaveMemory(proposal: String) {
        if (isFinishing || isDestroyed) return
        memoryDialog?.dismiss()
        memoryDialog = AlertDialog.Builder(this)
            .setTitle("Remember this?")
            .setMessage(proposal)
            .setPositiveButton("Save") { _, _ ->
                lifecycleScope.launch {
                    val msg = when (brain.saveApprovedMemory(proposal)) {
                        MemorySaveResult.SAVED -> "Saved to Memory Vault"
                        MemorySaveResult.DUPLICATE -> "Already saved"
                        MemorySaveResult.SENSITIVE -> "Not saved: looks private (password, OTP, card or ID)"
                        MemorySaveResult.INVALID -> "Could not save this"
                    }
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("No thanks", null)
            .show()
    }

    private fun speakLooi(text: String) {
        if (!settings.soundEnabled || !isTtsReady) {
            binding.robotFaceView.currentEmotion = currentEmotion
            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        val ttsParams = Bundle().apply {
            if (ttsAudioSessionId > 0) {
                putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, ttsAudioSessionId)
            }
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, ttsParams, utteranceId)
    }

    private fun setupButtons() {
        binding.robotFaceView.setOnClickListener {
            if (binding.robotFaceView.currentEmotion == RobotEmotion.SLEEPING) {
                binding.robotFaceView.wakeUp()
                currentEmotion = RobotEmotion.HAPPY
                binding.tvEmotionStatus.text = "MOOD: HAPPY"
            } else {
                binding.robotFaceView.triggerBlink()
            }
        }

        binding.btnMic.setOnClickListener {
            if (isProcessing) {
                Toast.makeText(this, "LOOI soch raha hai…", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            speechRetryCount = 0
            if (isListening) {
                stopVoiceListening()
            } else {
                textToSpeech?.stop()
                lipSyncController.onSpeakingFinished(currentEmotion)
                startVoiceListening()
            }
        }

        binding.btnChatHistory.setOnClickListener {
            startActivity(Intent(this, ConversationActivity::class.java))
        }

        binding.btnApiKey.setOnClickListener { showApiKeyDialog() }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnToggleCamera.setOnClickListener {
            val enableCamera = !settings.cameraEnabled
            settings.cameraEnabled = enableCamera
            if (enableCamera) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    setupCamera()
                } else {
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                }
            } else {
                cameraXManager?.stopCamera()
                detectedObjectsList.clear()
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvDetectedObjects.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAMERA OFF"
                Toast.makeText(this, "Camera & tracking paused", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnScanObject.setOnClickListener {
            triggerObjectScan()
        }
    }

    private fun startVoiceListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.languageCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, settings.languageCode)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo dost! LOOI sun raha hai…")
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            Toast.makeText(this, "Could not start speech listener", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVoiceListening() {
        isListening = false
        updateMicIndicator(false)
        binding.robotFaceView.mouthAmplitude = 0f
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        binding.robotFaceView.currentEmotion = currentEmotion
        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
    }

    private fun triggerObjectScan() {
        if (!settings.objectDetectionEnabled) {
            Toast.makeText(this, "Object detection is disabled in Settings", Toast.LENGTH_SHORT).show()
            return
        }

        binding.tvEmotionStatus.text = "SCANNING OBJECTS…"
        binding.robotFaceView.currentEmotion = RobotEmotion.CURIOUS
        val emotionBeforeScan = currentEmotion

        lifecycleScope.launch {
            val dominant = detectedObjectsList.firstOrNull()
            if (dominant.isNullOrBlank()) {
                val msg = "Point the front camera at an object so I can identify it!"
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = msg
                binding.robotFaceView.currentEmotion = emotionBeforeScan
                speakLooi(msg)
                return@launch
            }

            val groqResult = groqManager.describeDetectedObject(dominant)
            groqResult.onSuccess { description ->
                binding.tvSubtitleSpeaker.text = "LOOI Vision ($dominant):"
                binding.tvSubtitleText.text = description
                speakLooi(description)
            }.onFailure {
                val localSummary = "I detected: ${detectedObjectsList.joinToString(", ")}."
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = localSummary
                speakLooi(localSummary)
            }
        }
    }

    // FaceTrackingListener implementation
    override fun onFaceTracked(lookX: Float, lookY: Float, emotion: RobotEmotion, face: Face) {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            binding.robotFaceView.setLookTarget(lookX, lookY)
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = emotion
                binding.robotFaceView.currentEmotion = emotion
                binding.tvEmotionStatus.text = "MOOD: ${emotion.name}"
            }
            binding.tvTrackingBadge.text =
                String.format(Locale.US, "FACE (%.1f, %.1f)", lookX, lookY)
        }
    }

    override fun onFaceLost() {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = RobotEmotion.SEARCHING
                binding.robotFaceView.currentEmotion = RobotEmotion.SEARCHING
                binding.tvEmotionStatus.text = "SEARCHING…"
                binding.tvTrackingBadge.text = "SEARCHING…"
            }
        }
    }

    // ObjectDetectionListener implementation
    override fun onObjectsDetected(objects: List<DetectedObject>, primaryLabel: String?) {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            if (!settings.objectDetectionEnabled || !settings.cameraEnabled) {
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
                return@runOnUiThread
            }

            val labels = objects.flatMap { it.labels }
                .filter { it.confidence > 0.45f }
                .sortedByDescending { it.confidence }
                .map { it.text }
                .distinct()

            if (labels.isNotEmpty()) {
                detectedObjectsList.clear()
                detectedObjectsList.addAll(labels.take(5))
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: ${detectedObjectsList.joinToString(", ")}"
            } else if (!primaryLabel.isNullOrBlank()) {
                detectedObjectsList.clear()
                detectedObjectsList.add(primaryLabel)
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: $primaryLabel"
            } else {
                // Clear stale object labels when nothing is detected in the current frame
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        memoryDialog?.dismiss()
        memoryDialog = null
        lipSyncController.release()
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        } finally {
            speechRecognizer = null
        }
        isTtsReady = false
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {
        } finally {
            textToSpeech = null
        }
        cameraXManager?.release()
        cameraXManager = null
        visionAnalyzer?.close()
        visionAnalyzer = null
    }

    private companion object {
        /** How long the instant reaction expression is shown before the thinking animation starts. */
        const val REACTION_MS = 450L
    }
}
