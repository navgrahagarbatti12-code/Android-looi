package com.looi.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.objects.DetectedObject
import com.looi.ai.LooiApplication
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.audio.LipSyncController
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.camera.CameraXManager
import com.looi.ai.databinding.ActivityMainBinding
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.CompositeVisionAnalyzer
import com.looi.ai.vision.FaceTrackingListener
import com.looi.ai.vision.ObjectDetectionListener
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Main LOOI AI Companion Activity.
 * Integrates CameraX front camera, simultaneous ML Kit Face & Object Tracking,
 * configurable Groq/Gemini AI conversation, Speech-to-Text, Text-to-Speech,
 * Room persistent memory, and real-time lip-sync.
 */
class MainActivity : AppCompatActivity(), FaceTrackingListener, ObjectDetectionListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private lateinit var lipSyncController: LipSyncController
    private lateinit var geminiClient: GeminiLiveClient
    private lateinit var groqManager: GroqManager

    private var cameraXManager: CameraXManager? = null
    private var visionAnalyzer: CompositeVisionAnalyzer? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isListening = false
    private var ttsAudioSessionId = 0

    private var currentEmotion = RobotEmotion.HAPPY
    private val detectedObjectsList = mutableListOf<String>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.containsKey(Manifest.permission.CAMERA)) {
            val cameraGranted = permissions[Manifest.permission.CAMERA] == true
            if (cameraGranted && settings.cameraEnabled) {
                setupCamera()
            } else if (!cameraGranted) {
                cameraXManager?.stopCamera()
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAMERA DENIED"
                Toast.makeText(
                    this,
                    "Camera permission denied. Enable it in Android Settings for face & object tracking.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        if (permissions.containsKey(Manifest.permission.RECORD_AUDIO)) {
            val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
            if (audioGranted) {
                initSpeechRecognizer()
            } else {
                Toast.makeText(
                    this,
                    "Microphone permission denied. Voice input requires microphone access.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager
        geminiClient = GeminiLiveClient(settings)
        groqManager = GroqManager(settings)
        lipSyncController = LipSyncController(this, binding.robotFaceView, lifecycleScope)

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        ttsAudioSessionId = audioManager?.generateAudioSessionId() ?: 0

        initTextToSpeech()
        setupButtons()
        applySettingsToRuntime()
        checkPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToRuntime()
        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            cameraXManager?.isCameraRunning() != true
        ) {
            setupCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        if (isListening) {
            stopVoiceListening()
        }
        textToSpeech?.stop()
        lipSyncController.onSpeakingFinished(currentEmotion)
    }

    private fun applySettingsToRuntime() {
        binding.robotFaceView.animationSpeedMultiplier = settings.eyeAnimationSpeed

        visionAnalyzer?.isObjectDetectionEnabled = settings.objectDetectionEnabled
        visionAnalyzer?.isFrontCameraMirrored = settings.mirrorCamera

        if (!settings.objectDetectionEnabled) {
            binding.tvDetectedObjects.visibility = View.GONE
        }

        if (!settings.cameraEnabled) {
            cameraXManager?.stopCamera()
            binding.cameraPreviewCard.visibility = View.GONE
            binding.tvDetectedObjects.visibility = View.GONE
        } else if (binding.cameraPreviewCard.visibility != View.VISIBLE &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) {
            binding.cameraPreviewCard.visibility = View.VISIBLE
        }

        if (isTtsReady) {
            applyTtsSettings()
        }
    }

    private fun checkPermissionsAndStart() {
        val permissionsToRequest = mutableListOf<String>()
        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            if (settings.cameraEnabled) {
                setupCamera()
            }
            initSpeechRecognizer()
        }
    }

    private fun setupCamera() {
        if (!settings.cameraEnabled) return
        if (cameraXManager == null) {
            cameraXManager = CameraXManager(this, this, binding.cameraPreviewView)
        }
        if (visionAnalyzer == null) {
            visionAnalyzer = CompositeVisionAnalyzer(
                faceListener = this,
                objectListener = this,
                isObjectDetectionEnabled = settings.objectDetectionEnabled,
                isFrontCameraMirrored = settings.mirrorCamera
            )
        }

        val analyzer = visionAnalyzer ?: return
        binding.cameraPreviewCard.visibility = View.VISIBLE
        cameraXManager?.startCamera(analyzer) { error ->
            runOnUiThread {
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAM ERROR"
                Toast.makeText(
                    this,
                    "Camera unavailable: ${error.localizedMessage ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                applyTtsSettings()

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingStarted(ttsAudioSessionId)
                            binding.tvEmotionStatus.text = "STATE: SPEAKING"
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingFinished(currentEmotion)
                            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            lipSyncController.onSpeakingFinished(currentEmotion)
                            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                        }
                    }
                })
            }
        }
    }

    private fun applyTtsSettings() {
        val tts = textToSpeech ?: return
        val locale = Locale.forLanguageTag(settings.languageCode)
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "IN"))
        }

        val preferredVoice = settings.voiceName
        if (preferredVoice.isNotBlank()) {
            val matched = tts.voices?.firstOrNull { it.name == preferredVoice }
            if (matched != null) {
                tts.voice = matched
            }
        }

        tts.setPitch(settings.speechPitch)
        tts.setSpeechRate(settings.speechSpeed)
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    binding.tvSubtitleSpeaker.text = "LOOI AI (Listening…)"
                    binding.tvEmotionStatus.text = "STATE: LISTENING"
                    binding.robotFaceView.currentEmotion = RobotEmotion.LISTENING
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = (rmsdB / 10f).coerceIn(0f, 1f)
                    binding.robotFaceView.mouthAmplitude = normalized * 0.4f
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isListening = false
                    binding.robotFaceView.mouthAmplitude = 0f
                    binding.tvEmotionStatus.text = "STATE: THINKING"
                    binding.robotFaceView.currentEmotion = RobotEmotion.THINKING
                }

                override fun onError(error: Int) {
                    isListening = false
                    binding.robotFaceView.mouthAmplitude = 0f
                    binding.robotFaceView.currentEmotion = currentEmotion
                    binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        binding.tvSubtitleSpeaker.text = "LOOI AI"
                        binding.tvSubtitleText.text = "Mic error ($error). Tap mic to try again."
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    binding.robotFaceView.mouthAmplitude = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull().orEmpty()
                    if (spokenText.isNotBlank()) {
                        processUserQuery(spokenText)
                    } else {
                        binding.robotFaceView.currentEmotion = currentEmotion
                        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        binding.tvSubtitleText.text = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun processUserQuery(query: String) {
        lifecycleScope.launch {
            binding.tvSubtitleSpeaker.text = "You said:"
            binding.tvSubtitleText.text = query

            val memoryRepo = LooiApplication.instance.memoryRepository
            if (settings.saveHistoryEnabled) {
                memoryRepo.recordUserMessage(query, currentEmotion.name)
            }

            val contextSummary = memoryRepo.getRecentContextSummary()
            binding.tvEmotionStatus.text = "STATE: THINKING"
            binding.robotFaceView.currentEmotion = RobotEmotion.THINKING

            val useGroq = when (settings.aiProvider) {
                SettingsManager.PROVIDER_GROQ -> true
                SettingsManager.PROVIDER_BACKEND -> false
                else -> settings.groqApiKey.isNotBlank()
            }

            val result = if (useGroq) {
                groqManager.chatCompletion(
                    userMessage = query,
                    detectedEmotion = currentEmotion.name,
                    detectedObjects = detectedObjectsList.toList(),
                    historyContext = contextSummary
                )
            } else {
                geminiClient.sendConversationTurn(
                    userMessage = query,
                    detectedEmotion = currentEmotion.name,
                    detectedObjects = detectedObjectsList.toList(),
                    historyContext = contextSummary
                )
            }

            result.onSuccess { reply ->
                if (settings.saveHistoryEnabled) {
                    memoryRepo.recordLooiResponse(reply)
                }
                binding.tvSubtitleSpeaker.text = "LOOI AI:"
                binding.tvSubtitleText.text = reply
                speakLooi(reply)
            }.onFailure { err ->
                binding.robotFaceView.currentEmotion = RobotEmotion.SAD
                binding.tvEmotionStatus.text = "NETWORK / API ERROR"
                binding.tvSubtitleSpeaker.text = "LOOI AI (Setup Needed):"
                binding.tvSubtitleText.text = err.localizedMessage
                    ?: "Network error. Check Settings for Groq API Key or Backend URL."
            }
        }
    }

    private fun speakLooi(text: String) {
        if (!settings.soundEnabled || !isTtsReady) {
            binding.robotFaceView.currentEmotion = currentEmotion
            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        val ttsParams = Bundle().apply {
            if (ttsAudioSessionId > 0) {
                putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, ttsAudioSessionId)
            }
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, ttsParams, utteranceId)
    }

    private fun setupButtons() {
        binding.robotFaceView.setOnClickListener {
            if (binding.robotFaceView.currentEmotion == RobotEmotion.SLEEPING) {
                binding.robotFaceView.wakeUp()
                currentEmotion = RobotEmotion.HAPPY
                binding.tvEmotionStatus.text = "MOOD: HAPPY"
            } else {
                binding.robotFaceView.triggerBlink()
            }
        }

        binding.btnMic.setOnClickListener {
            if (isListening) {
                stopVoiceListening()
            } else {
                textToSpeech?.stop()
                lipSyncController.onSpeakingFinished(currentEmotion)
                startVoiceListening()
            }
        }

        binding.btnChatHistory.setOnClickListener {
            startActivity(Intent(this, ConversationActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnToggleCamera.setOnClickListener {
            if (binding.robotFaceView.currentEmotion == RobotEmotion.SLEEPING) {
                binding.robotFaceView.wakeUp()
                currentEmotion = RobotEmotion.HAPPY
                Toast.makeText(this, "LOOI is awake", Toast.LENGTH_SHORT).show()
            } else {
                textToSpeech?.stop()
                if (isListening) stopVoiceListening()
                binding.robotFaceView.goToSleep()
                currentEmotion = RobotEmotion.SLEEPING
                Toast.makeText(this, "LOOI is sleeping", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnScanObject.setOnClickListener {
            triggerObjectScan()
        }
    }

    private fun startVoiceListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.languageCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, settings.languageCode)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo dost! LOOI sun raha hai…")
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            Toast.makeText(this, "Could not start speech listener", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVoiceListening() {
        isListening = false
        binding.robotFaceView.mouthAmplitude = 0f
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        binding.robotFaceView.currentEmotion = currentEmotion
        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
    }

    private fun triggerObjectScan() {
        if (!settings.objectDetectionEnabled) {
            Toast.makeText(this, "Object detection is disabled in Settings", Toast.LENGTH_SHORT).show()
            return
        }

        binding.tvEmotionStatus.text = "SCANNING OBJECTS…"
        binding.robotFaceView.currentEmotion = RobotEmotion.CURIOUS

        lifecycleScope.launch {
            val dominant = detectedObjectsList.firstOrNull()
            if (dominant.isNullOrBlank()) {
                val msg = "Point the front camera at an object so I can identify it!"
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = msg
                speakLooi(msg)
                return@launch
            }

            val groqResult = groqManager.describeDetectedObject(dominant)
            groqResult.onSuccess { description ->
                binding.tvSubtitleSpeaker.text = "LOOI Vision ($dominant):"
                binding.tvSubtitleText.text = description
                speakLooi(description)
            }.onFailure {
                val localSummary = "I detected: ${detectedObjectsList.joinToString(", ")}."
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = localSummary
                speakLooi(localSummary)
            }
        }
    }

    // FaceTrackingListener implementation
    override fun onFaceTracked(lookX: Float, lookY: Float, emotion: RobotEmotion, face: Face) {
        runOnUiThread {
            binding.robotFaceView.setLookTarget(lookX, lookY)
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = emotion
                binding.robotFaceView.currentEmotion = emotion
                binding.tvEmotionStatus.text = "MOOD: ${emotion.name}"
            }
            binding.tvTrackingBadge.text =
                String.format(Locale.US, "FACE (%.1f, %.1f)", lookX, lookY)
        }
    }

    override fun onFaceLost() {
        runOnUiThread {
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = RobotEmotion.SEARCHING
                binding.robotFaceView.currentEmotion = RobotEmotion.SEARCHING
                binding.tvEmotionStatus.text = "SEARCHING…"
                binding.tvTrackingBadge.text = "SEARCHING…"
            }
        }
    }

    // ObjectDetectionListener implementation
    override fun onObjectsDetected(objects: List<DetectedObject>, primaryLabel: String?) {
        runOnUiThread {
            if (!settings.objectDetectionEnabled || !settings.cameraEnabled) {
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
                return@runOnUiThread
            }

            val labels = objects.flatMap { it.labels }
                .filter { it.confidence > 0.45f }
                .sortedByDescending { it.confidence }
                .map { it.text }
                .distinct()

            if (labels.isNotEmpty()) {
                detectedObjectsList.clear()
                detectedObjectsList.addAll(labels.take(5))
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: ${detectedObjectsList.joinToString(", ")}"
            } else if (!primaryLabel.isNullOrBlank()) {
                detectedObjectsList.clear()
                detectedObjectsList.add(primaryLabel)
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: $primaryLabel"
            } else {
                // Clear stale object labels when nothing is detected in the current frame
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        lipSyncController.release()
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        } finally {
            speechRecognizer = null
        }
        isTtsReady = false
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {
        } finally {
            textToSpeech = null
        }
        visionAnalyzer?.close()
        visionAnalyzer = null
        cameraXManager?.release()
        cameraXManager = null
    }
}
