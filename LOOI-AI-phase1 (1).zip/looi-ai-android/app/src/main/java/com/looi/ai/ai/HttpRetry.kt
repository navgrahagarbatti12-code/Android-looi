package com.looi.ai.ai

import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/** HTTP status + body of the final attempt. */
data class HttpResult(val code: Int, val body: String)

/**
 * Executes a request with bounded retries for transient failures
 * (network IOException, HTTP 429 and 5xx) using linear backoff.
 * Throws the last IOException if every attempt failed at the network level.
 */
object HttpRetry {
    suspend fun execute(
        client: OkHttpClient,
        attempts: Int = 3,
        buildRequest: () -> Request
    ): HttpResult {
        var lastError: IOException? = null
        for (attempt in 1..attempts) {
            val isLast = attempt == attempts
            try {
                client.newCall(buildRequest()).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    val transient = response.code == 429 || response.code >= 500
                    if (!transient || isLast) return HttpResult(response.code, body)
                }
            } catch (e: IOException) {
                lastError = e
                if (isLast) throw e
            }
            delay(700L * attempt)
        }
        throw lastError ?: IOException("Request failed")
    }
}
