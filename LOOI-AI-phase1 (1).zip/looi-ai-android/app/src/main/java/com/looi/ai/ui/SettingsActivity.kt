package com.looi.ai.ui

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.looi.ai.LooiApplication
import com.looi.ai.databinding.ActivitySettingsBinding
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.launch
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settings: SettingsManager

    private var tts: TextToSpeech? = null
    private var availableVoices: List<Voice> = emptyList()

    private val providerCodes = listOf(
        SettingsManager.PROVIDER_AUTO,
        SettingsManager.PROVIDER_GROQ,
        SettingsManager.PROVIDER_BACKEND
    )
    private val providerLabels = listOf(
        "Auto (Groq if key set, else Backend)",
        "Groq Direct API",
        "Companion Backend Proxy"
    )

    private val groqModels = listOf(
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "mixtral-8x7b-32768"
    )

    private val languageCodes = listOf("hi-IN", "en-IN", "en-US")
    private val languageLabels = listOf(
        "Hindi / Hinglish (hi-IN)",
        "English India (en-IN)",
        "English US (en-US)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager

        setSupportActionBar(binding.toolbarSettings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarSettings.setNavigationOnClickListener { finish() }

        setupSpinners()
        setupSliders()
        loadSavedValues()
        initVoiceList()

        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
        }

        binding.btnClearMemory.setOnClickListener {
            lifecycleScope.launch {
                LooiApplication.instance.memoryRepository.clearMemory()
                Toast.makeText(
                    this@SettingsActivity,
                    "LOOI conversation memory cleared",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setupSpinners() {
        binding.spinnerAiProvider.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            providerLabels
        )
        binding.spinnerGroqModel.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            groqModels
        )
        binding.spinnerLanguage.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            languageLabels
        )
    }

    private fun setupSliders() {
        binding.seekSpeechSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = 0.5f + (progress / 100f)
                binding.tvSpeechSpeedValue.text = String.format(Locale.US, "%.2fx", speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekEyeSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = 0.4f + (progress / 100f)
                binding.tvEyeSpeedValue.text = String.format(Locale.US, "%.2fx", speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun loadSavedValues() {
        val providerIdx = providerCodes.indexOf(settings.aiProvider).coerceAtLeast(0)
        binding.spinnerAiProvider.setSelection(providerIdx)

        binding.etGroqApiKey.setText(settings.groqApiKey)

        val modelIdx = groqModels.indexOf(settings.groqModel).coerceAtLeast(0)
        binding.spinnerGroqModel.setSelection(modelIdx)

        binding.etBackendUrl.setText(settings.backendUrl)

        val langIdx = languageCodes.indexOf(settings.languageCode).coerceAtLeast(0)
        binding.spinnerLanguage.setSelection(langIdx)

        val speechProgress = ((settings.speechSpeed - 0.5f) * 100f).toInt().coerceIn(0, 150)
        binding.seekSpeechSpeed.progress = speechProgress
        binding.tvSpeechSpeedValue.text = String.format(Locale.US, "%.2fx", settings.speechSpeed)

        val eyeProgress = ((settings.eyeAnimationSpeed - 0.4f) * 100f).toInt().coerceIn(0, 160)
        binding.seekEyeSpeed.progress = eyeProgress
        binding.tvEyeSpeedValue.text = String.format(Locale.US, "%.2fx", settings.eyeAnimationSpeed)

        binding.switchCameraEnabled.isChecked = settings.cameraEnabled
        binding.switchMirrorCamera.isChecked = settings.mirrorCamera
        binding.switchObjectDetection.isChecked = settings.objectDetectionEnabled
        binding.switchSoundEnabled.isChecked = settings.soundEnabled
        binding.switchSaveHistory.isChecked = settings.saveHistoryEnabled
    }

    private fun initVoiceList() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val voices = tts?.voices
                    ?.filter { it.locale.language == "hi" || it.locale.language == "en" }
                    ?.sortedBy { it.name }
                    .orEmpty()

                availableVoices = voices
                val labels = mutableListOf("System Default Voice")
                labels.addAll(voices.map { "${it.locale.displayLanguage} (${it.name})" })

                runOnUiThread {
                    if (isDestroyed || isFinishing) return@runOnUiThread
                    binding.spinnerVoice.adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        labels
                    )
                    val savedName = settings.voiceName
                    if (savedName.isNotBlank()) {
                        val idx = voices.indexOfFirst { it.name == savedName }
                        if (idx >= 0) {
                            binding.spinnerVoice.setSelection(idx + 1)
                        }
                    }
                }
            }
        }
    }

    private fun saveSettings() {
        val enteredBackendUrl = binding.etBackendUrl.text?.toString().orEmpty().trim()
            .ifBlank { SettingsManager.DEFAULT_BACKEND_URL }
        if (!settings.isBackendUrlAllowedBySecurityPolicy(enteredBackendUrl)) {
            Toast.makeText(
                this,
                "Physical devices require https:// for remote Backend URLs (http:// is allowed only for 10.0.2.2/localhost).",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        settings.aiProvider = providerCodes.getOrElse(binding.spinnerAiProvider.selectedItemPosition) {
            SettingsManager.PROVIDER_AUTO
        }
        settings.groqApiKey = binding.etGroqApiKey.text?.toString().orEmpty().trim()
        settings.groqModel = groqModels.getOrElse(binding.spinnerGroqModel.selectedItemPosition) {
            SettingsManager.DEFAULT_GROQ_MODEL
        }
        settings.backendUrl = enteredBackendUrl
        settings.languageCode = languageCodes.getOrElse(binding.spinnerLanguage.selectedItemPosition) { "hi-IN" }

        val selectedVoicePos = binding.spinnerVoice.selectedItemPosition
        settings.voiceName = if (selectedVoicePos > 0 && selectedVoicePos - 1 < availableVoices.size) {
            availableVoices[selectedVoicePos - 1].name
        } else {
            ""
        }

        settings.speechSpeed = 0.5f + (binding.seekSpeechSpeed.progress / 100f)
        settings.eyeAnimationSpeed = 0.4f + (binding.seekEyeSpeed.progress / 100f)
        settings.cameraEnabled = binding.switchCameraEnabled.isChecked
        settings.mirrorCamera = binding.switchMirrorCamera.isChecked
        settings.objectDetectionEnabled = binding.switchObjectDetection.isChecked
        settings.soundEnabled = binding.switchSoundEnabled.isChecked
        settings.saveHistoryEnabled = binding.switchSaveHistory.isChecked

        Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
