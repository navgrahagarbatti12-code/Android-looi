package com.looi.ai.ai.brain

enum class UserLanguage { HINDI, HINGLISH, ENGLISH }

/** Detects whether the user wrote Devanagari Hindi, Roman-script Hinglish, or English. */
object LanguageDetector {

    private val hinglishWords = setOf(
        "kya", "hai", "hain", "nahi", "nahin", "kaise", "kaisa", "kaun", "kyun", "kyu", "mujhe", "mera", "meri",
        "tum", "tumhe", "tumhara", "aap", "aapka", "haan", "han", "accha", "acha", "theek", "thik", "batao",
        "bolo", "karo", "kar", "ho", "hoon", "hun", "raha", "rahi", "rahe", "yaar", "bhai", "dost", "abhi",
        "aaj", "kal", "kab", "kahan", "mein", "me", "ko", "ka", "ki", "ke", "se", "par", "aur", "ya", "lekin",
        "bahut", "bohot", "yaad", "rakho", "bhool", "sunao", "chalo", "suno", "dikhao", "khol", "kholo"
    )

    fun detect(text: String): UserLanguage {
        var devanagari = 0
        var letters = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letters++
                if (ch in '\u0900'..'\u097F') devanagari++
            }
        }
        if (letters == 0) return UserLanguage.ENGLISH
        if (devanagari.toFloat() / letters > 0.3f) return UserLanguage.HINDI

        val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return UserLanguage.ENGLISH
        val hits = words.count { it in hinglishWords }
        // Words like "me", "ho", "ka" also exist in English, so require a real share of the sentence.
        return if (hits >= 2 && hits.toFloat() / words.size >= 0.25f) UserLanguage.HINGLISH else UserLanguage.ENGLISH
    }

    /** Prompt instruction: reply in the language the user just used. */
    fun replyInstruction(lang: UserLanguage): String = when (lang) {
        UserLanguage.HINDI -> "The user wrote in Hindi (Devanagari). Reply in natural spoken Hindi using Devanagari script."
        UserLanguage.HINGLISH -> "The user wrote Hinglish (Hindi in Roman letters). Reply in the same casual Hinglish, in Roman letters."
        UserLanguage.ENGLISH -> "The user wrote in English. Reply in clear, natural English."
    }
}
