package com.looi.ai.ai.groq

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.looi.ai.ai.HttpRetry
import com.looi.ai.ai.brain.ChatMessage
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Groq AI manager (OpenAI-compatible Chat Completions over HTTPS).
 * The API key comes only from SettingsManager (Keystore-backed storage) and is never logged.
 * Real API responses only: every failure is returned as an error, never replaced by canned text.
 */
class GroqManager(
    private val settingsManager: SettingsManager
) {
    private val tag = "GroqManager"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Legacy single-prompt entry point (object descriptions, Conversation screen fallback). */
    suspend fun chatCompletion(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> {
        val languageInstruction = when (settingsManager.languageCode) {
            "hi-IN" -> "Reply naturally in warm, friendly Hindi or Hinglish (Roman Hindi + English mix) in 1 to 3 short sentences."
            "en-IN" -> "Reply in warm, friendly Indian English in 1 to 3 short sentences."
            else -> "Reply in warm, friendly English in 1 to 3 short sentences."
        }
        val visionContext = buildString {
            append("User emotion: $detectedEmotion. ")
            if (detectedObjects.isNotEmpty()) {
                append("Visible objects around user: ${detectedObjects.joinToString(", ")}.")
            }
        }
        val messages = mutableListOf(
            ChatMessage(
                ChatMessage.SYSTEM,
                "You are LOOI AI, an expressive, curious, and caring robot companion.\n$languageInstruction\n" +
                    "Keep responses conversational, concise, and natural for Text-to-Speech.\n$visionContext"
            )
        )
        if (historyContext.isNotBlank() && historyContext != "No prior history.") {
            messages.add(ChatMessage(ChatMessage.SYSTEM, "Recent conversation context:\n$historyContext"))
        }
        messages.add(ChatMessage(ChatMessage.USER, userMessage))
        return complete(messages, temperature = 0.7f, maxTokens = 220)
    }

    /** Sends a full multi-turn conversation to Groq using the configured model. */
    suspend fun complete(
        messages: List<ChatMessage>,
        temperature: Float,
        maxTokens: Int
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = settingsManager.groqApiKey
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Groq API key not configured. Add it using the key button or Settings.")
            )
        }
        if (!settingsManager.isOnline()) {
            return@withContext Result.failure(
                IOException("Internet connection nahi hai. Network check karke dobara try karein.")
            )
        }

        val jsonMessages = JsonArray().apply {
            messages.forEach { m ->
                add(JsonObject().apply {
                    addProperty("role", m.role)
                    addProperty("content", m.content)
                })
            }
        }
        val payload = JsonObject().apply {
            addProperty("model", settingsManager.groqModel)
            add("messages", jsonMessages)
            addProperty("temperature", temperature.coerceIn(0f, 1.5f))
            addProperty("max_tokens", maxTokens)
        }
        val bodyString = payload.toString()

        try {
            val result = HttpRetry.execute(client) {
                Request.Builder()
                    .url(GROQ_CHAT_URL)
                    .addHeader("Authorization", "Bearer $apiKey")
                    .post(bodyString.toRequestBody("application/json".toMediaType()))
                    .build()
            }

            if (result.code !in 200..299) {
                // Log only the status code: response bodies/headers are never logged.
                Log.e(tag, "Groq HTTP ${result.code}")
                return@withContext Result.failure(IOException(httpErrorMessage(result.code)))
            }

            val json = gson.fromJson(result.body, JsonObject::class.java)
            val reply = json?.getAsJsonArray("choices")
                ?.firstOrNull()
                ?.takeIf { it.isJsonObject }
                ?.asJsonObject
                ?.getAsJsonObject("message")
                ?.get("content")
                ?.takeIf { it.isJsonPrimitive }
                ?.asString
                ?.trim()

            if (reply.isNullOrBlank()) {
                Result.failure(IOException("Groq se khaali jawab aaya."))
            } else {
                Result.success(reply)
            }
        } catch (e: com.google.gson.JsonParseException) {
            Result.failure(IOException("Groq ka response samajh nahi aaya.", e))
        } catch (e: IOException) {
            Log.e(tag, "Groq network error: ${e.javaClass.simpleName}")
            Result.failure(IOException("Network error: Groq tak pahunch nahi paaye. Connection check karein.", e))
        }
    }

    /** Lists chat-capable model IDs available to the saved API key (GET /openai/v1/models). */
    suspend fun listChatModels(): Result<List<String>> = withContext(Dispatchers.IO) {
        val apiKey = settingsManager.groqApiKey
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Pehle Groq API key save karein."))
        }
        if (!settingsManager.isOnline()) {
            return@withContext Result.failure(IOException("Internet connection nahi hai."))
        }
        try {
            val result = HttpRetry.execute(client) {
                Request.Builder()
                    .url(GROQ_MODELS_URL)
                    .addHeader("Authorization", "Bearer $apiKey")
                    .get()
                    .build()
            }
            if (result.code !in 200..299) {
                return@withContext Result.failure(IOException(httpErrorMessage(result.code)))
            }
            val ids = gson.fromJson(result.body, JsonObject::class.java)
                ?.getAsJsonArray("data")
                ?.mapNotNull { it.takeIf { e -> e.isJsonObject }?.asJsonObject?.get("id")?.takeIf { i -> i.isJsonPrimitive }?.asString }
                .orEmpty()
                .filter { id -> NON_CHAT_MARKERS.none { id.contains(it, ignoreCase = true) } }
                .sorted()
            if (ids.isEmpty()) Result.failure(IOException("Koi chat model nahi mila."))
            else Result.success(ids)
        } catch (e: com.google.gson.JsonParseException) {
            Result.failure(IOException("Model list samajh nahi aayi.", e))
        } catch (e: IOException) {
            Result.failure(IOException("Network error: model list nahi mil payi.", e))
        }
    }

    private fun httpErrorMessage(code: Int): String = when (code) {
        401, 403 -> "Groq API key invalid hai ya permission nahi hai. Key check karein."
        400, 404 -> "Groq model unavailable ($code). Settings me koi aur model chunein."
        429 -> "Groq rate limit reached. Thodi der baad try karein."
        in 500..599 -> "Groq server abhi available nahi hai ($code). Baad me try karein."
        else -> "Groq API error ($code)"
    }

    suspend fun describeDetectedObject(
        objectName: String,
        userQuery: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = userQuery
            ?: "I see a $objectName in front of me. React to it as LOOI robot in 1-2 short friendly sentences."

        if (settingsManager.groqApiKey.isNotBlank()) {
            return@withContext chatCompletion(
                userMessage = prompt,
                detectedEmotion = "CURIOUS",
                detectedObjects = listOf(objectName),
                historyContext = ""
            )
        }

        val backendUrl = settingsManager.backendUrl
        if (backendUrl.isBlank() || !settingsManager.isBackendUrlAllowedBySecurityPolicy(backendUrl)) {
            return@withContext Result.failure(
                IllegalStateException("Groq API key ya valid HTTPS Backend URL Settings me set karein.")
            )
        }
        if (!settingsManager.isOnline()) {
            return@withContext Result.failure(IOException("Internet connection nahi hai."))
        }

        try {
            val bodyString = JsonObject().apply {
                addProperty("objectName", objectName)
                addProperty("query", prompt)
                addProperty("engine", "groq-llama3")
            }.toString()

            val result = HttpRetry.execute(client) {
                Request.Builder()
                    .url("$backendUrl/api/looi/groq")
                    .post(bodyString.toRequestBody("application/json".toMediaType()))
                    .build()
            }
            if (result.code !in 200..299) {
                return@withContext Result.failure(IOException("Backend error ${result.code}"))
            }
            val text = gson.fromJson(result.body, JsonObject::class.java)
                ?.get("description")?.takeIf { it.isJsonPrimitive }?.asString
            if (text.isNullOrBlank()) {
                Result.failure(IOException("Backend ne khaali description bheji."))
            } else {
                Result.success(text)
            }
        } catch (e: com.google.gson.JsonParseException) {
            Result.failure(IOException("Backend ka response samajh nahi aaya.", e))
        } catch (e: IOException) {
            Log.w(tag, "Backend request failed: ${e.javaClass.simpleName}")
            Result.failure(e)
        }
    }

    companion object {
        private const val GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
        private const val GROQ_MODELS_URL = "https://api.groq.com/openai/v1/models"
        private val NON_CHAT_MARKERS = listOf("whisper", "guard", "tts", "playai", "orpheus", "embed", "safeguard")
    }
}
