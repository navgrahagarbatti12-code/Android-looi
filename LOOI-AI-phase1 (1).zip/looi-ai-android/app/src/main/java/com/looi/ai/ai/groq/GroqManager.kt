package com.looi.ai.ai.groq

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Modular Groq AI Manager.
 * Calls Groq's OpenAI-compatible Chat Completions API directly when a user-configured
 * API key is present in SettingsManager, or falls back to the configured backend proxy.
 * Never hardcodes any API key.
 */
class GroqManager(
    private val settingsManager: SettingsManager
) {
    private val tag = "GroqManager"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun chatCompletion(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = settingsManager.groqApiKey
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Groq API key not configured. Open Settings to add your Groq API key.")
            )
        }

        val languageInstruction = when (settingsManager.languageCode) {
            "hi-IN" -> "Reply naturally in warm, friendly Hindi or Hinglish (Roman Hindi + English mix) in 1 to 3 short sentences."
            "en-IN" -> "Reply in warm, friendly Indian English in 1 to 3 short sentences."
            else -> "Reply in warm, friendly English in 1 to 3 short sentences."
        }

        val visionContext = buildString {
            append("User emotion: $detectedEmotion. ")
            if (detectedObjects.isNotEmpty()) {
                append("Visible objects around user: ${detectedObjects.joinToString(", ")}.")
            }
        }

        val systemPrompt = """
            You are LOOI AI, an expressive, curious, and caring desktop robot companion.
            $languageInstruction
            Keep responses conversational, concise, and natural for Text-to-Speech.
            $visionContext
        """.trimIndent()

        val messages = JsonArray().apply {
            add(JsonObject().apply {
                addProperty("role", "system")
                addProperty("content", systemPrompt)
            })
            if (historyContext.isNotBlank() && historyContext != "No prior history.") {
                add(JsonObject().apply {
                    addProperty("role", "system")
                    addProperty("content", "Recent conversation context:\n$historyContext")
                })
            }
            add(JsonObject().apply {
                addProperty("role", "user")
                addProperty("content", userMessage)
            })
        }

        val payload = JsonObject().apply {
            addProperty("model", settingsManager.groqModel)
            add("messages", messages)
            addProperty("temperature", 0.7)
            addProperty("max_tokens", 220)
        }

        val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(GROQ_CHAT_URL)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = when (response.code) {
                        401 -> "Invalid Groq API key. Please check Settings."
                        429 -> "Groq rate limit reached. Please wait a moment."
                        else -> "Groq API error (${response.code})"
                    }
                    Log.e(tag, "$errorMsg: $responseStr")
                    return@withContext Result.failure(IOException(errorMsg))
                }

                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val choices = json.getAsJsonArray("choices")
                val reply = choices?.firstOrNull()
                    ?.asJsonObject
                    ?.getAsJsonObject("message")
                    ?.get("content")
                    ?.asString
                    ?.trim()

                if (reply.isNullOrBlank()) {
                    return@withContext Result.failure(IOException("Empty response from Groq API"))
                }
                Result.success(reply)
            }
        } catch (e: Exception) {
            Log.e(tag, "Groq network error", e)
            Result.failure(IOException("Network error: ${e.localizedMessage ?: "Unable to reach Groq"}", e))
        }
    }

    suspend fun describeDetectedObject(
        objectName: String,
        userQuery: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = userQuery ?: "I see a $objectName in front of me. React to it as LOOI robot in 1-2 short friendly sentences."
        val apiKey = settingsManager.groqApiKey

        if (apiKey.isNotBlank()) {
            return@withContext chatCompletion(
                userMessage = prompt,
                detectedEmotion = "CURIOUS",
                detectedObjects = listOf(objectName),
                historyContext = ""
            )
        }

        // Fall back to configured backend proxy if no direct Groq key is set
        val backendUrl = settingsManager.backendUrl
        if (backendUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Configure a Groq API key or Backend URL in Settings.")
            )
        }

        try {
            val payload = JsonObject().apply {
                addProperty("objectName", objectName)
                addProperty("query", prompt)
                addProperty("engine", "groq-llama3")
            }

            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$backendUrl/api/looi/groq")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("Backend error ${response.code}"))
                }
                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val text = json.get("description")?.asString
                    ?: return@withContext Result.failure(IOException("Empty description from backend"))
                Result.success(text)
            }
        } catch (e: Exception) {
            Log.w(tag, "Groq backend request failed: ${e.message}")
            Result.failure(e)
        }
    }

    companion object {
        private const val GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
    }
}
