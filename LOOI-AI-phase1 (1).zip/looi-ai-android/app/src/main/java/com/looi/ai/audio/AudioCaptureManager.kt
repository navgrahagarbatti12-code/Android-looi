package com.looi.ai.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import androidx.core.content.ContextCompat
import kotlin.math.sqrt

interface AudioAmplitudeListener {
    fun onAmplitudeSampled(amplitude: Float) // 0.0f to 1.0f
}

/**
 * AudioCaptureManager samples microphone volume safely for standalone voice activity
 * and amplitude monitoring, enforcing runtime permission checks and single-thread lifecycle.
 *
 * Note: MainActivity uses Android SpeechRecognizer (which reports mic RMS via onRmsChanged)
 * and intentionally keeps AudioCaptureManager decoupled while SpeechRecognizer is active
 * to avoid simultaneous microphone hardware conflicts on Android devices.
 */
class AudioCaptureManager(
    private val context: Context,
    private val listener: AudioAmplitudeListener
) {
    private val tag = "AudioCaptureManager"
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private var audioRecord: AudioRecord? = null
    @Volatile
    private var isRecording = false
    private var recordingThread: Thread? = null
    private val lock = Any()

    fun hasRecordPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun startListening(): Boolean {
        synchronized(lock) {
            if (isRecording) {
                return true
            }
            if (!hasRecordPermission()) {
                Log.w(tag, "RECORD_AUDIO permission not granted; skipping AudioRecord start.")
                return false
            }

            val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE || minBufferSize <= 0) {
                Log.e(tag, "Invalid AudioRecord buffer size: $minBufferSize")
                return false
            }

            return try {
                val record = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    minBufferSize * 2
                )

                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(tag, "AudioRecord failed to initialize (state=${record.state})")
                    record.release()
                    return false
                }

                audioRecord = record
                record.startRecording()
                isRecording = true

                recordingThread = Thread({
                    val buffer = ShortArray(minBufferSize)
                    try {
                        while (isRecording) {
                            val activeRecord = audioRecord ?: break
                            val read = activeRecord.read(buffer, 0, buffer.size)
                            if (read > 0) {
                                var sum = 0.0
                                for (i in 0 until read) {
                                    val sample = buffer[i].toDouble()
                                    sum += sample * sample
                                }
                                val rms = sqrt(sum / read)
                                val normalized = ((rms / 32767.0).toFloat() * 3.5f).coerceIn(0f, 1f)
                                listener.onAmplitudeSampled(normalized)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w(tag, "Audio capture loop terminated: ${e.message}")
                    }
                }, "LooiAudioCaptureThread").apply { start() }

                true
            } catch (e: SecurityException) {
                Log.e(tag, "SecurityException starting AudioRecord", e)
                releaseInternal()
                false
            } catch (e: Exception) {
                Log.e(tag, "Failed to start AudioRecord", e)
                releaseInternal()
                false
            }
        }
    }

    fun stopListening() {
        synchronized(lock) {
            releaseInternal()
        }
    }

    private fun releaseInternal() {
        isRecording = false
        try {
            audioRecord?.let { record ->
                if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                }
                record.release()
            }
        } catch (e: Exception) {
            Log.w(tag, "Error stopping AudioRecord: ${e.message}")
        } finally {
            audioRecord = null
        }

        try {
            recordingThread?.join(300)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } finally {
            recordingThread = null
        }
        listener.onAmplitudeSampled(0f)
    }

    fun isListening(): Boolean = isRecording
}
