package com.looi.ai.settings

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InputValidatorsTest {
    @Test fun groqKey_validFormat() {
        assertTrue(InputValidators.isGroqKeyFormatValid("gsk_" + "a".repeat(30)))
    }

    @Test fun groqKey_rejectsBadValues() {
        assertFalse(InputValidators.isGroqKeyFormatValid(""))
        assertFalse(InputValidators.isGroqKeyFormatValid("sk-" + "a".repeat(30)))
        assertFalse(InputValidators.isGroqKeyFormatValid("gsk_short"))
        assertFalse(InputValidators.isGroqKeyFormatValid("gsk_" + "a".repeat(10) + " " + "b".repeat(10)))
    }

    @Test fun modelId() {
        assertTrue(InputValidators.isModelIdValid("llama-3.3-70b-versatile"))
        assertTrue(InputValidators.isModelIdValid("openai/gpt-oss-20b"))
        assertFalse(InputValidators.isModelIdValid("bad model"))
        assertFalse(InputValidators.isModelIdValid("x"))
    }

    @Test fun backendUrl_httpsAlwaysAllowed() {
        assertTrue(InputValidators.isBackendUrlAllowed("https://api.example.com"))
    }

    @Test fun backendUrl_httpOnlyForLocalHosts() {
        assertTrue(InputValidators.isBackendUrlAllowed("http://10.0.2.2:3000"))
        assertTrue(InputValidators.isBackendUrlAllowed("http://localhost:3000"))
        assertFalse(InputValidators.isBackendUrlAllowed("http://example.com"))
        assertFalse(InputValidators.isBackendUrlAllowed("http://10.0.2.2.evil.com"))
        assertFalse(InputValidators.isBackendUrlAllowed("ftp://example.com"))
        assertFalse(InputValidators.isBackendUrlAllowed("not a url"))
    }
}
