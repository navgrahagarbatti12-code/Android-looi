package com.looi.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class SmoothingFilterTest {
    @Test fun firstValuePassesThrough() {
        assertEquals(0.8f, SmoothingFilter(0.3f).filter(0.8f), 1e-6f)
    }

    @Test fun movesTowardTarget() {
        val f = SmoothingFilter(0.5f)
        f.filter(0f)
        assertEquals(0.5f, f.filter(1f), 1e-6f)
    }

    @Test fun resetForgetsHistory() {
        val f = SmoothingFilter(0.5f)
        f.filter(0f)
        f.reset()
        assertEquals(1f, f.filter(1f), 1e-6f)
    }
}
