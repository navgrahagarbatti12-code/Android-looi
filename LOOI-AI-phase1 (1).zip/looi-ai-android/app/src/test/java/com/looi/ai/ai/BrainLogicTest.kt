package com.looi.ai.ai

import com.looi.ai.ai.brain.*
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.personality.RobotPersonality
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainLogicTest {

    // ---- LanguageDetector ----
    @Test fun language_devanagari() = assertEquals(UserLanguage.HINDI, LanguageDetector.detect("आज मौसम कैसा है"))
    @Test fun language_hinglish() = assertEquals(UserLanguage.HINGLISH, LanguageDetector.detect("mujhe batao aaj kya karna hai"))
    @Test fun language_english() = assertEquals(UserLanguage.ENGLISH, LanguageDetector.detect("What is the capital of France?"))
    @Test fun language_englishWithMe() = assertEquals(UserLanguage.ENGLISH, LanguageDetector.detect("Tell me a story"))
    @Test fun language_empty() = assertEquals(UserLanguage.ENGLISH, LanguageDetector.detect("123 ???"))

    // ---- MemoryIntentParser ----
    @Test fun intent_remember() {
        assertEquals(MemoryIntent.Remember("my name is Rahul"), MemoryIntentParser.parse("Remember that my name is Rahul."))
        assertEquals(MemoryIntent.Remember("mera birthday 5 may hai"), MemoryIntentParser.parse("yaad rakho ki mera birthday 5 may hai"))
        assertEquals(MemoryIntent.Remember("मेरा नाम राहुल है"), MemoryIntentParser.parse("याद रखो कि मेरा नाम राहुल है"))
        assertEquals(MemoryIntent.Remember("I like tea"), MemoryIntentParser.parse("Hey LOOI, please remember I like tea"))
    }
    @Test fun intent_doYouRememberIsNotACommand() {
        assertEquals(MemoryIntent.None, MemoryIntentParser.parse("Do you remember my name?"))
    }
    @Test fun intent_forget() {
        assertEquals(MemoryIntent.Forget("my birthday"), MemoryIntentParser.parse("forget about my birthday"))
        assertEquals(MemoryIntent.Forget("meri age"), MemoryIntentParser.parse("bhool jao meri age"))
    }
    @Test fun intent_list() {
        assertEquals(MemoryIntent.ListMemories, MemoryIntentParser.parse("What do you remember about me?"))
        assertEquals(MemoryIntent.ListMemories, MemoryIntentParser.parse("tumhe kya yaad hai"))
    }
    @Test fun intent_search() {
        assertEquals(MemoryIntent.SearchConversations("cricket"), MemoryIntentParser.parse("search my old conversations for cricket"))
        assertEquals(MemoryIntent.SearchConversations("the trip"), MemoryIntentParser.parse("what did we talk about the trip?"))
        assertEquals(MemoryIntent.SearchConversations("exams"), MemoryIntentParser.parse("what did I say about exams?"))
    }
    @Test fun intent_normalChat() {
        assertEquals(MemoryIntent.None, MemoryIntentParser.parse("how is the weather today"))
        assertEquals(MemoryIntent.None, MemoryIntentParser.parse(""))
    }

    // ---- MemoryCategory ----
    @Test fun category() {
        assertEquals(MemoryCategory.INSTRUCTION, MemoryCategory.categorize("Always call me boss"))
        assertEquals(MemoryCategory.INSTRUCTION, MemoryCategory.categorize("hamesha Hindi me bolna"))
        assertEquals(MemoryCategory.PREFERENCE, MemoryCategory.categorize("I like masala chai"))
        assertEquals(MemoryCategory.FACT, MemoryCategory.categorize("my sister is called Riya"))
    }

    // ---- SensitiveDataFilter ----
    @Test fun sensitive() {
        assertTrue(SensitiveDataFilter.isSensitive("my password is hunter2"))
        assertTrue(SensitiveDataFilter.isSensitive("card 4111 1111 1111 1111"))
        assertTrue(SensitiveDataFilter.isSensitive("aadhaar 1234 5678 9012"))
        assertTrue(SensitiveDataFilter.isSensitive("मेरा पासवर्ड abc"))
        assertFalse(SensitiveDataFilter.isSensitive("I like cricket and tea"))
        assertFalse(SensitiveDataFilter.isSensitive("my birthday is 5 May 1999"))
    }

    // ---- ReplyParser ----
    @Test fun reply_stripsTags() {
        val p = ReplyParser.parse("Sure, I will! [emotion:happy] [remember: User likes tea]")
        assertEquals("Sure, I will!", p.text)
        assertEquals(RobotEmotion.HAPPY, p.emotion)
        assertEquals("User likes tea", p.memoryProposal)
    }
    @Test fun reply_noTags() {
        val p = ReplyParser.parse("Hello there")
        assertEquals("Hello there", p.text)
        assertNull(p.emotion); assertNull(p.memoryProposal)
    }
    @Test fun reply_danglingTagRemoved() {
        assertEquals("Hi", ReplyParser.parse("Hi [emotion:ha").text)
    }
    @Test fun reply_sensitiveProposalDropped() {
        assertNull(ReplyParser.parse("ok [remember: user's card number is 4111 1111 1111 1111]").memoryProposal)
    }
    @Test fun reply_unknownEmotionIgnoredButStripped() {
        val p = ReplyParser.parse("Fine [emotion:bored]")
        assertEquals("Fine", p.text); assertNull(p.emotion)
    }

    // ---- MemoryRanker ----
    private fun mem(id: Long, c: String, cat: String = MemoryCategory.FACT, t: Long = 1_000_000L) =
        RankableMemory(id, c, cat, t)

    @Test fun ranker_relevantFirstAndInstructionsAlways() {
        val list = listOf(
            mem(1, "User's sister is called Riya"),
            mem(2, "User likes cricket and plays every Sunday"),
            mem(3, "Always address the user as boss", MemoryCategory.INSTRUCTION)
        )
        val r = MemoryRanker.select(list, "who should I invite for cricket", now = 2_000_000L)
        assertEquals(listOf("Always address the user as boss"), r.instructions)
        assertEquals("User likes cricket and plays every Sunday", r.facts.first())
    }
    @Test fun ranker_emptyInput() = assertTrue(MemoryRanker.select(emptyList(), "hi", 0L).isEmpty)
    @Test fun ranker_respectsCharBudget() {
        val list = (1..20).map { mem(it.toLong(), "fact number $it " + "x".repeat(100)) }
        val r = MemoryRanker.select(list, "fact", 2_000_000L, maxItems = 20, maxChars = 300)
        assertTrue(r.facts.sumOf { it.length } <= 300)
    }

    // ---- PromptBuilder ----
    private fun ctx(history: List<ChatMessage> = emptyList(), proposals: Boolean = true, lang: UserLanguage = UserLanguage.ENGLISH) =
        BrainContext(
            userText = "hello", personality = RobotPersonality.FUNNY, language = lang, preferredLanguageCode = "hi-IN",
            memories = RankedMemories(listOf("Call me boss"), listOf("Likes tea")), recalledSnippets = listOf("USER: I love chess"),
            history = history, userEmotion = "HAPPY", visibleObjects = listOf("cup"), nowText = "Thursday, 12 November 2026, 10:00",
            allowMemoryProposals = proposals
        )

    @Test fun prompt_structure() {
        val msgs = PromptBuilder.build(ctx(listOf(ChatMessage("user", "a"), ChatMessage("assistant", "b"))))
        assertEquals("system", msgs.first().role)
        assertEquals(ChatMessage("user", "hello"), msgs.last())
        assertEquals(4, msgs.size)
        val sys = msgs.first().content
        assertTrue(sys.contains("Call me boss")); assertTrue(sys.contains("Likes tea"))
        assertTrue(sys.contains("I love chess")); assertTrue(sys.contains("cup"))
        assertTrue(sys.contains("[emotion:happy]")); assertTrue(sys.contains("[remember:"))
        assertTrue(sys.contains("playful"))
        assertTrue(sys.contains("prefer casual Hinglish"))
    }
    @Test fun prompt_noProposalInstructionWhenDisabled() {
        assertFalse(PromptBuilder.systemPrompt(ctx(proposals = false)).contains("[remember:"))
    }
    @Test fun prompt_historyTrimmedToBudget() {
        val long = (1..40).map { ChatMessage(if (it % 2 == 0) "assistant" else "user", "m$it " + "y".repeat(300)) }
        val trimmed = PromptBuilder.trimHistory(long)
        assertTrue(trimmed.size <= 12)
        assertTrue(trimmed.sumOf { it.content.length } <= 3200 + 310)
        assertTrue(trimmed.last().content.startsWith("m40"))
    }
}
