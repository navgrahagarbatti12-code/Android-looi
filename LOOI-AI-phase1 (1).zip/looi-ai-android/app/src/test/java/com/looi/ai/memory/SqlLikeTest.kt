package com.looi.ai.memory

import org.junit.Assert.assertEquals
import org.junit.Test

class SqlLikeTest {
    @Test fun escapesWildcards() {
        assertEquals("100\\% sure", SqlLike.escape("100% sure"))
        assertEquals("a\\_b", SqlLike.escape("a_b"))
        assertEquals("c:\\\\x", SqlLike.escape("c:\\x"))
        assertEquals("plain", SqlLike.escape("  plain "))
    }
}
