package com.looi.ai.personality

import com.looi.ai.avatar.RobotEmotion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalityTest {
    @Test fun sixPersonalities() = assertEquals(6, RobotPersonality.values().size)
    @Test fun fromId() {
        assertEquals(RobotPersonality.FUNNY, RobotPersonality.fromId("funny"))
        assertEquals(RobotPersonality.FRIENDLY, RobotPersonality.fromId("nonsense"))
        assertEquals(RobotPersonality.FRIENDLY, RobotPersonality.fromId(null))
    }
    @Test fun voiceFactorsSane() = RobotPersonality.values().forEach {
        assertTrue(it.pitchFactor in 0.8f..1.2f); assertTrue(it.speedFactor in 0.8f..1.2f)
        assertTrue(it.temperature in 0f..1f)
    }
    @Test fun reactions() {
        assertEquals(RobotEmotion.HAPPY, ExpressionReactor.reactionFor("thank you so much", RobotPersonality.FRIENDLY))
        assertEquals(RobotEmotion.SAD, ExpressionReactor.reactionFor("main bahut udaas hoon", RobotPersonality.FRIENDLY))
        assertEquals(RobotEmotion.SURPRISED, ExpressionReactor.reactionFor("wow that is amazing", RobotPersonality.FUNNY))
        assertEquals(RobotEmotion.ANGRY, ExpressionReactor.reactionFor("you are so annoying", RobotPersonality.FUNNY))
        assertEquals(RobotEmotion.SAD, ExpressionReactor.reactionFor("you are so annoying", RobotPersonality.EMOTIONAL))
    }
    @Test fun questionsOnlyCuriousForCuriousTypes() {
        assertEquals(RobotEmotion.CURIOUS, ExpressionReactor.reactionFor("how do planes fly", RobotPersonality.CURIOUS))
        assertNull(ExpressionReactor.reactionFor("how do planes fly", RobotPersonality.FRIENDLY))
        assertNull(ExpressionReactor.reactionFor("", RobotPersonality.CURIOUS))
    }
}
